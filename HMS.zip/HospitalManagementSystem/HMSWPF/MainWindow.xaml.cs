﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

using HMS.Entities;
using HMS.Exceptions;
using HMS.BL;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        int count = 3;
        private void Reset_Click(object sender, RoutedEventArgs e)
        {
            ussername.Text = "";
            password.Text = "";
        }

        private void LoginBut_Click(object sender, RoutedEventArgs e)
        {
            
            try
            {
                if (count>0)
                {
                    count--;
                    Login details = new Login();

                    details.Username = ussername.Text;
                    details.Password = password.Text;

                    HMSBL obj = new HMSBL();

                    if (obj.LoginCredentials(details))
                    {
                        HMS p = new HMS();
                        p.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("User Doesn't Exists....");
                        MessageBox.Show("try Left: " + count);
                        ussername.Focus();
                    }
                }
                else
                {
                    this.Close();
                }
            }
            catch (HMSExceptions )
            {
                MessageBox.Show(e.ToString());
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception v)
            {
                MessageBox.Show(v.Message);   
            }
            
        }
              
    }
}
