﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using HMS.Entities;
using HMS.Exceptions;
using HMS.BL;
using System.Data.SqlClient;

namespace HMSWPF
{
    /// <summary>
    /// Interaction logic for HMS.xaml
    /// </summary>
    public partial class HMS : Window
    {
        public HMS()
        {
            InitializeComponent();
            //Experiment --MessageBox.Show("U r In ");
        }

        private void Submit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient p = new Patient();
                p.PatientId = Convert.ToInt32(PatientID.Content);
                p.PatientName = Convert.ToString(PatientName.Text);
                p.PatientCategory = (PatientType)Enum.Parse(typeof(PatientType), Category.Text);

                HMSBL hbl = new HMSBL();
                bool flag = hbl.AddPatient(p);
                if (flag)
                {
                    MessageBox.Show("Patient ADDED..");
                }
                else
                {
                    MessageBox.Show("Enable to add Patient");
                }
            }
            catch(HMSExceptions h)
            {
                MessageBox.Show(h.Message.ToString());
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Message.ToString());
            }
            catch (Exception v)
            {
                MessageBox.Show(v.Message.ToString());
            }
            
        }

        private void TabItem_Loaded(object sender, RoutedEventArgs e)
        {
            //PatientID.Content = "Hello";
            //Have to write code here for pid
            try
            {
                HMSBL hbl = new HMSBL();
                PatientID.Content = Convert.ToString(hbl.Pid());
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Message.ToString());
            }
            catch (Exception v)
            {
                MessageBox.Show(v.Message.ToString());
            }            
        }        

        private void ViewPatient_GotFocus(object sender, RoutedEventArgs e)
        {
            try
            {
                HMSBL hbl = new HMSBL();
                List<Patient> viewList = hbl.ShowPatient();

                patientid1.Content = viewList[0].PatientId;
                patientname1.Content = viewList[0].PatientName;
                Category1.Content = viewList[0].PatientCategory;

                patientid2.Content = viewList[1].PatientId;
                patientname2.Content = viewList[1].PatientName;
                category2.Content = viewList[1].PatientCategory;      
            }
            catch (SqlException s)
            {
                MessageBox.Show(s.Message.ToString());
            }
            catch (Exception v)
            {
                MessageBox.Show(v.Message.ToString());
            }            

        }      
    }
}
