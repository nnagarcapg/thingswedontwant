﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using HMS.Entities;
using HMS.Exceptions;
using HMS.DAL;

namespace HMS.BL
{
    public class HMSBL
    {
        HMSDAL hdao = new HMSDAL();

        public bool ValidatePatient(Patient obj)
        {
            bool flag = true;
            StringBuilder sb = new StringBuilder();
            if (obj.PatientName==string.Empty)
            {
                flag = false;
                sb.Append("Patient Name Cant be Empty");
            }
            if (flag==false)
            {
                throw new HMSExceptions(sb.ToString());
            }
            return flag;
        }

        public bool AddPatient(Patient newP)
        {
            try
            {
                bool flag = false;
                if (ValidatePatient(newP))
                {
                    flag = hdao.AddPatient(newP);
                }
                return flag;               
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }                      
        }

        public List<Patient> ShowPatient()
        {
            try
            {
                List<Patient> retList = hdao.ShowPatient();
                return retList;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }

        public bool LoginCredentials(Login rec)
        {
            try
            {
                return hdao.LoginCredentials(rec);
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }            
        }

        public int Pid()
        {
            try
            {
                return hdao.Pid();
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }

    }
}
