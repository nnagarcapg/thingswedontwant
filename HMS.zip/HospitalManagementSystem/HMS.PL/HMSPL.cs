﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using HMS.Entities;
using HMS.Exceptions;
using HMS.BL;

namespace HMS.PL
{
    class HMSPL
    {
        static void Main(string[] args)
        {
            HMSPL obj=new HMSPL();

            int choice = 0;
            do
            {
                Console.Clear();
                Console.WriteLine("1. Add Patient");
                Console.WriteLine("2. List Patient");
                Console.WriteLine("3. Exit");
                Console.WriteLine("Your Choice: ");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1: obj.AddPatient();
                        break;

                    case 2: obj.ShowPatient();
                        break;

                    case 3: System.Environment.Exit(0);
                        break;

                    default: Console.WriteLine("Invalid Choice");
                        break;
                }
                
            } while (choice !=3);
        }

        public void AddPatient()
        {
            Console.Clear();
            Patient obj = new Patient();
            Console.WriteLine("Patient Id: ");
            obj.PatientId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Patient Name: ");
            obj.PatientName = Console.ReadLine();
            Console.WriteLine("Patient Category(Caps Only)");
            obj.PatientCategory = (PatientType)Enum.Parse(typeof(PatientType),Console.ReadLine());

            HMSBL hbl = new HMSBL();
            hbl.AddPatient(obj);

            Console.ReadLine();
        }

        public void ShowPatient()
        {
            Console.Clear();
            HMSBL hbl = new HMSBL();

            List<Patient> showP = hbl.ShowPatient();

            Console.WriteLine("ID\t\tPatient Name\t\tCategory");
            foreach (var item in showP)
            {
                Console.WriteLine("{0}\t\t{1}\t\t{2}",item.PatientId, item.PatientName, item.PatientCategory);
            }

            Console.ReadLine();
        }
    }
}
