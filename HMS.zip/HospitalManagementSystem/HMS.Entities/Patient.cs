﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Entities
{
    public enum PatientType
    {
        IN,OUT  
    };

    public class Patient
    {
        int patientId;
        string patientName;
        PatientType patientCategory;
                
        public Patient()//Default Constructor
        {

        }

        public Patient(int iD, string name, PatientType category)//Paramatrized Constructor
        {
            this.PatientId = iD;
            this.PatientName = name;
            this.patientCategory = category;
        }

        public string PatientName
        {
            get { return patientName; }
            set { patientName = value; }
        }

        public int PatientId
        {
            get { return patientId; }
            set { patientId = value; }
        }

        public PatientType PatientCategory
        {
            get { return patientCategory; }
            set { patientCategory = value; }
        }
    }
}
