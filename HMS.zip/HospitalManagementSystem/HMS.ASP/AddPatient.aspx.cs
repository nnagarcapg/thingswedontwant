﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using HMS.Entities;
using HMS.Exceptions;
using HMS.BL;
using System.Data.SqlClient;

namespace HMS.ASP
{
    public partial class AddPatient : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            this.UnobtrusiveValidationMode = System.Web.UI.UnobtrusiveValidationMode.None; //Required when using validators
            try
            {
                HMSBL hbl = new HMSBL();
                PatientID.Text = Convert.ToString(hbl.Pid());
            }
            catch (SqlException s)
            {
                //MessageBox.Show(s.Message.ToString());
                Response.Write("<script>alert('s.Message.ToString()');</script>");
            }
            catch (Exception v)
            {
                //MessageBox.Show(v.Message.ToString());
                Response.Write("<script>alert('v.Message.ToString()');</script>");
            }   
        }

        protected void Submit_Click(object sender, EventArgs e)
        {
            try
            {
                Patient p = new Patient();
                p.PatientId = Convert.ToInt32(PatientID.Text);
                p.PatientName = Convert.ToString(PatientName.Text);
                p.PatientCategory = (PatientType)Enum.Parse(typeof(PatientType), Category.Text);

                HMSBL hbl = new HMSBL();
                bool flag = hbl.AddPatient(p);
                if (flag)
                {
                    //MessageBox.Show("Patient ADDED..");
                    Response.Write("<script>alert('Patient ADDED...');</script>");
                }
                else
                {
                    //MessageBox.Show("Enable to add Patient");
                    Response.Write("<script>alert('Enable to add Patient...');</script>");
                }
            }
            catch (HMSExceptions h)
            {
                //MessageBox.Show(h.Message.ToString());
                //Response.Write(h.Message.ToString());
                Response.Write("<script>alert('');</script>");
            }
            catch (SqlException s)
            {
                //MessageBox.Show(s.Message.ToString());
                Response.Write("<script>alert('s.Message.ToString()');</script>");
            }
            catch (Exception v)
            {
                //MessageBox.Show(v.Message.ToString());
                Response.Write("<script>alert('v.Message.ToString()');</script>");
            }
        }
    }
}