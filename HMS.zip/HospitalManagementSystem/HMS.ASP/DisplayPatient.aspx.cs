﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using HMS.Entities;
using HMS.Exceptions;
using HMS.BL;
using System.Data.SqlClient;

namespace HMS.ASP
{
    public partial class DisplayPatient : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            HMSBL obj = new HMSBL();
            grdpatient.DataSource = obj.ShowPatient();
            grdpatient.DataBind();
        }
    }
}