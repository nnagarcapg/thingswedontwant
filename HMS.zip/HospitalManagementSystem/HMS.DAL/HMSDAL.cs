﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;//FOr ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable


using HMS.Entities;
using HMS.Exceptions;

namespace HMS.DAL
{
    public class HMSDAL
    {
        public static List<Patient> myPatient = new List<Patient>();

        public bool AddPatient(Patient newP)//Working 17/01
        {
            try
            {
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);

                SqlCommand cmd = new SqlCommand("INSERT INTO HMS_NN.Patient VALUES(@id, @n, @c)", con);

                cmd.Parameters.Add(new SqlParameter("@id", Convert.ToString(newP.PatientId)));
                cmd.Parameters.Add(new SqlParameter("@n", Convert.ToString(newP.PatientName)));
                cmd.Parameters.Add(new SqlParameter("@c", Convert.ToString(newP.PatientCategory)));

                con.Open();
                if (cmd.ExecuteNonQuery() > 0)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch(SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }
        }

        public List<Patient> ShowPatient()
        {
            try
            {
                List<Patient> getList = new List<Patient>();
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);

                SqlDataAdapter adap = new SqlDataAdapter("SELECT * FROM HMS_NN.Patient", con);
                //Making an Obejct of SqlCommandBuilder
                SqlCommandBuilder builder = new SqlCommandBuilder();
                //Making an object of DataTable for holding the whole Table
                DataTable dTable = new DataTable();
                //Filling Data into DataTable Object
                adap.Fill(dTable);

                foreach (DataRow row in dTable.Rows)
                {
                    Patient obj = new Patient();
                    obj.PatientId = Convert.ToInt32(row[0]);
                    obj.PatientName = Convert.ToString(row[1]);
                    obj.PatientCategory = (PatientType)Enum.Parse(typeof(PatientType), row[2].ToString());

                    getList.Add(obj);
                }

                return getList;
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception v)
            {
                throw v;
            }           
        }

        public bool LoginCredentials(Login rec)//Working 17/01
        {
            //Write ado.net querry
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM HMS_NN.LoginCreds where USERNAME=@u AND PASS=@p", con);

                cmd.Parameters.Add(new SqlParameter("@u", rec.Username));
                cmd.Parameters.Add(new SqlParameter("@p", rec.Password));

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }       
        }

        public int Pid()//Working 17/01
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                con.Open();

                //The Insert DML to add employee record
                SqlCommand cmd = new SqlCommand("Select MAX(pid)+1 FROM HMS_NN.Patient", con);

                int ret = Convert.ToInt32(cmd.ExecuteScalar());
                con.Close();

                return ret;
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }                  
        }
    }
}
