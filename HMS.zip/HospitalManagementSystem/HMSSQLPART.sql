--use Mumbai13Training
--CREATE SCHEMA HMS_NN

--CREATE TABLE HMS_NN.Patient(PID INT PRIMARY KEY, PNAME VARCHAR(25), PCATG VARCHAR(3))

--CREATE TABLE HMS_NN.LoginCreds(USERNAME VARCHAR(15) PRIMARY KEY, PASS VARCHAR(15))

INSERT INTO HMS_NN.LoginCreds VALUES('ABC','1234')
INSERT INTO HMS_NN.LoginCreds VALUES('Admin','Admin')

INSERT INTO HMS_NN.Patient VALUES(1001, 'John Doe', 'IN')
INSERT INTO HMS_NN.Patient VALUES(1002, 'Jane Doe', 'IN')

Select MAX(pid)+1 FROM HMS_NN.Patient

insert into HMS_NN.Patient VALUES(@id, @n, @c)

select * from HMS_NN.Patient

select TOP 2(PID), PNAME, PCATG FROM HMS_NN.Patient

select * from HMS_NN.LoginCreds


Create TABLE HMS_NN.ProductASP(ProductID INT IDENTITY(100,1) PRIMARY KEY, ProductName VARCHAR(50), Price Money)
SELECT * FROM HMS_NN.ProductASP
INSERT INTO HMS_NN.ProductASP VALUES('Anchor', 550)
INSERT INTO HMS_NN.ProductASP VALUES('Bajaj Fan', 5000)
INSERT INTO HMS_NN.ProductASP VALUES('Chetak', 50000)

CREATE PROCEDURE HMS_NN.usp_productasp
AS
BEGIN
	SELECT * FROM HMS_NN.ProductASP
END

exec HMS_NN.usp_productasp

SELECT MAX(ProductID)+1 FROM HMS_NN.ProductASP
INSERT INTO HMS_NN.ProductASP(ProductID, ProductName, Price) VALUES(102,'CGKP', 150000)
DELETE FROM HMS_NN.ProductASP WHERE ProductID = 105
UPDATE HMS_NN.ProductASP SET ProductName='CGKP', Price=15000 WHERE ProductID=102
SELECT * FROM HMS_NN.ProductASP WHERE ProductID=105

CREATE PROCEDURE dbo.usp_productasp
AS
BEGIN
	SELECT * FROM dbo.ProductASP
END

exec dbo.usp_productasp



