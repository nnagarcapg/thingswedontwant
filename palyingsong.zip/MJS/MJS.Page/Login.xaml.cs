﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for Login.xaml
    /// </summary>
    public partial class Login : Window
    {
        public Login()
        {
            InitializeComponent();
        }

        private void btnsubmit_Click(object sender, RoutedEventArgs e)
        {

            try
            {
                if (rdbadmin.IsChecked == true)
                {
                    Employee o = new Employee();
                    o.EmployeeID = Convert.ToInt32(txtuserid.Text);
                    o.Password = txtpassword.Text;

                    EmployeeBL obj = new EmployeeBL();
                    bool flag = obj.LoginCredentials(o);
                    if (flag)
                    {
                        AdminPage apo = new AdminPage();
                        apo.Show();
                        //MessageBox.Show("U May Proceed");
                    }
                    else
                    {
                        MessageBox.Show("Error");
                    }
                }
                else if (rdbuser.IsChecked == true)
                {
                    Customer o = new Customer();
                    o.CustomerID = Convert.ToInt32(txtuserid.Text);
                    o.Password = txtpassword.Text;

                    CustomerBL obj = new CustomerBL();
                    bool flag = obj.LoginCredentials(o);
                    if (flag)
                    {
                        UserPage upo = new UserPage();
                        upo.Show();
                        //MessageBox.Show("U May Proceed");
                    }
                    else
                    {
                        MessageBox.Show("Error");
                    }
                }
                else
                {
                    MessageBox.Show("Please Choose Login Type");
                }
            }
            catch (SqlException h)
            {
                MessageBox.Show(h.Message.ToString());
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message.ToString());
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            HomePage hpo = new HomePage();
            this.Close();
            hpo.Show();
        }

        private void Hyperlink_Click_1(object sender, RoutedEventArgs e)
        {
            Registration rego = new Registration();
            this.Close();
            rego.Show();
        }
    }
}
