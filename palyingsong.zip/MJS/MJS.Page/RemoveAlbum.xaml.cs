﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for RemoveAlbum.xaml
    /// </summary>
    public partial class RemoveAlbum : Window
    {
        public RemoveAlbum()
        {
            InitializeComponent();
        }

        private void btndelete_Click(object sender, RoutedEventArgs e)
        {
            if (txtalbumid.Text != "")
            {
                try
                {
                    AlbumBL abo = new AlbumBL();
                    int id = Convert.ToInt32(txtalbumid.Text);
                    bool flag = abo.DeleteAlbumById(id);
                    if (flag)
                    {
                        MessageBox.Show("Album with ID: " + id + "is Removed");
                    }
                    else
                    {
                        MessageBox.Show("Unable to Delete Album");
                    }
                }
                catch (ValueUnavailableException vue)
                {
                    MessageBox.Show(vue.Message.ToString());
                }
                catch (SqlException se)
                {
                    MessageBox.Show(se.Message.ToString());
                }
                catch (Exception f)
                {
                    MessageBox.Show(f.Message.ToString());
                }
            }
            else
            {
                MessageBox.Show("Please Enter Album ID");
                txtalbumid.Text = "";
                txtalbumid.Focus();
            }
        }
    }
}
