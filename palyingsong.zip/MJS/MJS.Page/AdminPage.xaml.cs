﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for AdminPage.xaml
    /// </summary>
    public partial class AdminPage : Window
    {
        public AdminPage()
        {
            InitializeComponent();
        }

        private void btnremovemusic_Click(object sender, RoutedEventArgs e)
        {
            RemoveSong rso = new RemoveSong();
            rso.Show();
        }

        private void btnaddmusic_Click(object sender, RoutedEventArgs e)
        {
            AddSong aso = new AddSong();
            aso.Show();
        }

        private void btnaddalbum_Click(object sender, RoutedEventArgs e)
        {
            AddAlbum aao = new AddAlbum();
            aao.Show();
        }

        private void btnremovealbum_Click(object sender, RoutedEventArgs e)
        {
            RemoveAlbum rao = new RemoveAlbum();
            rao.Show();
        }

        private void btnaddcustomer_Click(object sender, RoutedEventArgs e)
        {
            AddCustomer aco = new AddCustomer();
            aco.Show();
        }

        private void btnsearchcustomer_Click(object sender, RoutedEventArgs e)
        {
            if (txtid.Text != "")
            {
                CustomerBL bobj = new CustomerBL();
                int id = Convert.ToInt32(txtid.Text);
                Customer cobj = bobj.SearchCustomerById(id);
                List<Customer> list = new List<Customer>();
                list.Add(cobj);
                grdadmin.ItemsSource = list;
            }
            else
            {
                CustomerBL bobj = new CustomerBL();
                grdadmin.ItemsSource = bobj.DisplayCustomer();
                //MessageBox.Show("Please enter Customer Id in Text Box");
            }
        }

        private void btnremovecustomer_Click(object sender, RoutedEventArgs e)
        {
            RemoveCustomer rco = new RemoveCustomer();
            rco.Show();
        }

        private void btnupdatedmusic_Click(object sender, RoutedEventArgs e)
        {
            UpdateSong uso = new UpdateSong();
            uso.Show();
        }

        private void btnupdatealbum_Click(object sender, RoutedEventArgs e)
        {
            UpdateAlbum uao = new UpdateAlbum();
            uao.Show();
        }

        private void btnsearchalbum_Click(object sender, RoutedEventArgs e)
        {
            if (txtid.Text != "")
            {
                AlbumBL bobj = new AlbumBL();
                int year = Convert.ToInt32(txtid.Text);
                grdadmin.ItemsSource = bobj.SearchAlbumByYear(year);
                
            }
            else
            {
                AlbumBL bobj = new AlbumBL();
                grdadmin.ItemsSource = bobj.ShowAllAlbum();
               
            }
        }
    }
}
