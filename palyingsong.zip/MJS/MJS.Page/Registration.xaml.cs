﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Entity;
using MJS.BL;
using MJS.Exceptions;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void btnregister_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                if (rdbadmin.IsChecked == true)
                {
                    EmployeeBL obj = new EmployeeBL();

                    Employee o = new Employee();
                    o.EmployeeID = Convert.ToInt32(txtid.Text);
                    o.EmpName = txtname.Text;
                    o.Address = txtaddress.Text;
                    o.City = txtcity.Text;
                    o.DOB = Convert.ToDateTime(txtdob.Text);
                    o.Password = txtpassword.Text;
                    o.MobileNo = txtmobileno.Text;
                    bool flag = obj.RegisterEmployee(o);
                    if (flag)
                    {
                        MessageBox.Show("Employee added...");
                    }
                    else
                    {
                        MessageBox.Show("Unable to add Employee");
                    }
                }
                else if(rdbuser.IsChecked == true)
                {
                    CustomerBL obj = new CustomerBL();

                    Customer o = new Customer();
                    o.CustomerID = Convert.ToInt32(txtid.Text);
                    o.CustName = txtname.Text;
                    o.Address = txtaddress.Text;
                    o.City = txtcity.Text;
                    o.DOB = Convert.ToDateTime(txtdob.Text);
                    o.Password = txtpassword.Text;
                    o.MobileNo = txtmobileno.Text;
                    bool flag = obj.AddCustomer(o);
                    if (flag)
                    {
                        MessageBox.Show("Customer added...");
                    }
                    else
                    {
                        MessageBox.Show("Unable to add Customer");
                    }
                }
                else
                {
                    MessageBox.Show("!!!!Please choose user type......");
                }
            }
            catch   (EmployeeExceptions l)
            {
                MessageBox.Show(l.Message.ToString());
            }
            catch  (CustomerException k)
            {
                MessageBox.Show(k.Message.ToString());
            }
            catch (SqlException v)
            {
                MessageBox.Show(v.Message.ToString());
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message.ToString());
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Login loo = new Login();
            this.Close();
            loo.Show();
        }

        private void Hyperlink_Click_1(object sender, RoutedEventArgs e)
        {
            HomePage hpo = new HomePage();
            this.Close();
            hpo.Show();
        }

    }
}
