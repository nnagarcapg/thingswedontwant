﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;//FOr FIle

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;
using MJS.Exceptions;

namespace MJS.DAL
{
    public class SongsDAL
    {
        //
        public bool RemoveSongBySongId(int songId)
        {
            //Creating connection Object
            SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

            bool removesong = false;;
            try
            {
                SqlCommand cmd = new SqlCommand("delete from MJS.Songs where SongID= @i", connobj);
                cmd.Parameters.AddWithValue("@i", songId);

                connobj.Open();
                int result = cmd.ExecuteNonQuery();
                connobj.Close();

                if (result > 0)
                    removesong = true;
            }
            catch (SqlException se)
            {
                connobj.Close();
                throw se;
            }
            catch (Exception e)
            {
                connobj.Close();
                throw e;
            }
            return removesong;
        }
        
        //Search Song By Singer
        public List<Songs> SearchSongBySinger(string singerName)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object
            SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);

            try
            {
                SqlCommand cmd = new SqlCommand("select * from MJS.Songs where Singer=@name", connobj);
                cmd.Parameters.AddWithValue("@name", singerName);
                connobj.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                connobj.Close();
            }
            catch (SqlException se)
            {
                connobj.Close();
                throw se;
            }
            catch (Exception e)
            {
                connobj.Close();
                throw e;
            }
            return getsongList;
        }

        //Search Song By Genre
        public List<Songs> SearchSongByLanguage(string langname)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object
            SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("select * from MJS.Songs where Lang=@name", connobj);
                cmd.Parameters.Add(new SqlParameter("@name", langname));
                connobj.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                connobj.Close();
                
            }
            catch (SqlException se)
            {
                connobj.Close();
                throw se;
            }
            catch (Exception e)
            {
                connobj.Close();
                throw e;
            }
            return getsongList;
        }

        // Search Song By Year
        public List<Songs> SearchSongByYear(int year)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object
            SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            
            try
            {
                SqlCommand cmd = new SqlCommand("select * from MJS.Songs where RYear=@year", connobj);
                cmd.Parameters.AddWithValue("@year", year);
                connobj.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                connobj.Close();
                
            }
            catch (SqlException se)
            {
                connobj.Close();
                throw se;
            }
            catch (Exception e)
            {
                connobj.Close();
                throw e;
            }
            return getsongList;
        }

        //Updating a song
        public bool UpdateSong(Songs s)
        {
            bool uploadSong = false;
            //Creating connection Object
            SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

            try
            {

                SqlCommand cmd = new SqlCommand("UPDATE MJS.Songs SET SongName=@n, Singer=@s, Movie=@m, ComposedBy=@c, Actor=@a, Actress=@ac, Lyrics=@l, RYear=@y, AlbumID=@ai, Lang=@lang WHERE SongID=@i ", connobj);

                cmd.Parameters.Add(new SqlParameter("@i", s.SongsID));
                cmd.Parameters.Add(new SqlParameter("@n", s.SongName));
                cmd.Parameters.Add(new SqlParameter("@s", s.Singer));
                cmd.Parameters.Add(new SqlParameter("@m", s.Movie));
                cmd.Parameters.Add(new SqlParameter("@c", s.ComposedBy));
                cmd.Parameters.Add(new SqlParameter("@a", s.Actor));
                cmd.Parameters.Add(new SqlParameter("@ac", s.Actress));
                cmd.Parameters.Add(new SqlParameter("@l", s.Lyrics));
                cmd.Parameters.Add(new SqlParameter("@y", s.Year));
                cmd.Parameters.Add(new SqlParameter("@ai", s.AlbumID));
                cmd.Parameters.Add(new SqlParameter("@lang", s.Language));


                connobj.Open();
                int result = cmd.ExecuteNonQuery();
                connobj.Close();
                if (result > 0)
                {
                    uploadSong = true;
                }
            }
            catch (SqlException se)
            {
                connobj.Close();
                throw se;
            }
            catch (Exception e)
            {
                connobj.Close();
                throw e;
            }
            return uploadSong;
        }

        //Upload Song 
        public bool UploadSong(Songs s)
        {
            bool uploadSong;
            try
            {
                //Creating connection Object
                SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

                SqlCommand cmd = new SqlCommand("insert into MJS.Songs values(@i,@n,@s,@m,@c,@a,@ac,@l,@y,@ai,@lang,@sp)", connobj);

                cmd.Parameters.Add(new SqlParameter("@i", s.SongsID));
                cmd.Parameters.Add(new SqlParameter("@n", s.SongName));
                cmd.Parameters.Add(new SqlParameter("@s", s.Singer));
                cmd.Parameters.Add(new SqlParameter("@m", s.Movie));
                cmd.Parameters.Add(new SqlParameter("@c", s.ComposedBy));
                cmd.Parameters.Add(new SqlParameter("@a", s.Actor));
                cmd.Parameters.Add(new SqlParameter("@ac", s.Actress));
                cmd.Parameters.Add(new SqlParameter("@l", s.Lyrics));
                cmd.Parameters.Add(new SqlParameter("@y", s.Year));
                cmd.Parameters.Add(new SqlParameter("@ai", s.AlbumID));
                cmd.Parameters.Add(new SqlParameter("@lang", s.Language));
                if (File.Exists(s.SPath))
                {
                    FileStream file = new FileStream(s.SPath, FileMode.Open);
                    cmd.Parameters.AddWithValue("@sp", file);
                }
                else
                {
                    string m = "File does not Exits";
                    throw new SongsExceptions(m);
                }

                connobj.Open();
                int result = cmd.ExecuteNonQuery();
                connobj.Close();
                if (result > 0)
                {
                    uploadSong = true;
                }
                else
                {
                    uploadSong = false;
                }
                return uploadSong;
            }
            catch (Exception e)
            {
                throw e;
            }

        }

        //Searcg song by Actor Name
        public List<Songs> SearchSongByActor(string actorName)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object
            SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("select * from MJS.Songs where Actor=@name", connobj);
                cmd.Parameters.Add(new SqlParameter("@name", actorName));
                connobj.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                connobj.Close();
            }
            catch (SqlException se)
            {
                connobj.Close();
                throw se;
            }
            catch (Exception e)
            {
                connobj.Close();
                throw e;
            }
            return getsongList;
        }

        //Search songs by Actress name
        public List<Songs> SearchSongByActress(string actressName)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object
            SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("select * from MJS.Songs where Actress=@name", connobj);
                cmd.Parameters.AddWithValue("@name", actressName);
                connobj.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                connobj.Close();
            }
            catch (SqlException se)
            {
                connobj.Close();
                throw se;
            }
            catch (Exception e)
            {
                connobj.Close();
                throw e;
            }
            return getsongList;
        }

        // Search Song By Movie
        public List<Songs> SearchSongByMovie(string movieName)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object
            SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("select * from MJS.Songs where Movie=@name", connobj);
                cmd.Parameters.Add(new SqlParameter("@name", movieName));
                connobj.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                connobj.Close();
            }
            catch (SqlException se)
            {
                connobj.Close();
                throw se;
            }
            catch (Exception e)
            {
                connobj.Close();
                throw e;
            }
            return getsongList;
        }
        
        //--------------
        //Remove Song By Song Name
        public bool RemoveSongBySongName(string songName)
        {
            bool removesong;
            try
            {
                //Creating connection Object
                SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

                SqlCommand cmd;
                string query = "delete from MJS.Songs where SongName= @name";

                cmd = new SqlCommand(query, connobj);
                cmd.Parameters.Add(new SqlParameter("@name", songName));

                connobj.Open();

                int result = cmd.ExecuteNonQuery();

                connobj.Close();

                if (result > 0)
                    removesong = true;

                else
                    return removesong = false;

                return removesong;


            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Search Song By Composer
        public List<Songs> SearchSongByComposer(string name)
        {
            try
            {
                List<Songs> getsongList = new List<Songs>();

                //Creating connection Object
                SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);
                string query = "select * from MJS.Songs where ComposedBy=@name";

                SqlCommand cmd = new SqlCommand(query, connobj);
                cmd.Parameters.Add(new SqlParameter("@name", name));
                connobj.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.HasRows)
                {
                    sdr.Read();
                    foreach (var item in getsongList)
                    {
                        Songs sobj = new Songs();
                        sobj.SongsID = Convert.ToInt16(sdr[0]);
                        sobj.SongName = sdr[1].ToString();
                        sobj.Singer = sdr[2].ToString();
                        sobj.Movie = sdr[3].ToString();
                        sobj.ComposedBy = sdr[4].ToString();
                        sobj.Actor = sdr[5].ToString();
                        sobj.Actress = sdr[6].ToString();
                        sobj.Lyrics = sdr[7].ToString();
                        sobj.Year = sdr.GetInt32(8);
                        sobj.AlbumID = Convert.ToInt16(sdr[9]);
                        sobj.Language = sdr[10].ToString();
                        getsongList.Add(sobj);

                    }
                }
                connobj.Close();
                return getsongList;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Update Singer
        public bool UpdateSinger(int songId, string singerName)
        {
            bool updatesinger;
            try
            {
                //Creating connection Object
                SqlConnection connobj = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

                SqlCommand cmd;
                //Query for Update Singer
                string query = "update MJS.Songs set Singer=@n where SongsID=@i ";

                //Passing Parameters 
                cmd = new SqlCommand(query, connobj);


                cmd.Parameters.Add(new SqlParameter("@n", singerName));
                cmd.Parameters.Add(new SqlParameter("@i", songId));


                connobj.Open();

                //Calling ExecuteNonQuery to show result is either true or false
                int result = cmd.ExecuteNonQuery();

                connobj.Close();
                if (result > 0)
                {
                    updatesinger = true;
                }
                else
                {
                    updatesinger = false;
                }
                return updatesinger;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        //Search Song By Genre
        public List<Songs> SearchSongByGenre(string genre)
        {
            try
            {

                List<Songs> getgenreList = new List<Songs>();

                //Connection String
                string connstring = "DATA SOURCE=ndamssql\\sqlilearn;INITIAL CATALOG=Mumbai13Training;user id=sqluser;password=sqluser;";

                //Creating connection Object
                SqlConnection connobj = new SqlConnection(connstring);

                string query = "select * from MJS.Songs where Genre=@genre";
                SqlCommand cmd = new SqlCommand(query, connobj);
                cmd.Parameters.Add(new SqlParameter("@genre", genre));
                connobj.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.HasRows)
                {
                    sdr.Read();
                    foreach (var item in getgenreList)
                    {
                        Songs sobj = new Songs();
                        sobj.SongsID = Convert.ToInt16(sdr[0]);
                        sobj.SongName = sdr[1].ToString();
                        sobj.Singer = sdr[2].ToString();
                        sobj.Movie = sdr[3].ToString();
                        sobj.ComposedBy = sdr[4].ToString();
                        sobj.Actor = sdr[5].ToString();
                        sobj.Actress = sdr[6].ToString();
                        sobj.Lyrics = sdr[7].ToString();
                        sobj.Year = sdr.GetInt32(8);
                        sobj.AlbumID = Convert.ToInt16(sdr[9]);
                        sobj.Language = sdr[10].ToString();
                        getgenreList.Add(sobj);
                    }
                }
                connobj.Close();
                return getgenreList;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }
}
