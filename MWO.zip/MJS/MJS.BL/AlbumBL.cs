﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


using System.Text.RegularExpressions;
using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.DAL;

namespace MJS.BL
{
    public class AlbumBL
    {
        public bool AddAlbum(Album a)
        {
            bool flag = false;
            try
            {
                AlbumDAL pbj = new AlbumDAL();
                if (ValidateAlbum(a))
                {
                    flag = pbj.AddAlbum(a);
                }
            }
            catch (SqlException s)
            {
                throw s;
            }
            catch (Exception w)
            {
                throw w;
            }

            return flag;
        }
        
        public List<Album> ShowAllAlbum()
        {
            List<Album> rlist = null;
            try
            {
                AlbumDAL dobj = new AlbumDAL();
                rlist = dobj.ShowAllAlbum();
            }
            catch (SqlException e)
            {
                throw e;
            }
            catch (Exception w)
            {
                throw w;
            }
            return rlist;
        }

        public bool UpdateAlbum(Album eAlbm)
        {
            bool flag = false;
            try
            {
                AlbumDAL dobj = new AlbumDAL();
                if (ValidateAlbum(eAlbm))
                {
                    flag = dobj.UpdateAlbum(eAlbm);
                }
            }
            catch (SqlException e)
            {
                throw e;
            }
            catch (Exception w)
            {
                throw w;
            }
            return flag;
        }

        public bool DeleteAlbumById(int albId)
        {
            bool flag = false;
            try
            {
                AlbumDAL ado = new AlbumDAL();
                flag = ado.DeleteAlbumById(albId);
            }
            catch (SqlException e)
            {
                throw e;
            }
            catch (Exception w)
            {
                throw w;
            }
            return flag;
        }

        public List<Album> SearchAlbumByName(string albName)
        {
            List<Album> rlist = null;
            try
            {

            }
            catch (SqlException e)
            {
                throw e;
            }
            catch (Exception w)
            {
                throw w;
            }
            return rlist;
        }

         public List<Album> SearchAlbumByYear(int albYear)
        {
            List<Album> rlist = new List<Album>();
            try
            {
                AlbumDAL dobj = new AlbumDAL();
                rlist = dobj.SearchAlbumByYear(albYear);
            }
            catch (SqlException e)
            {
                throw e;
            }
            catch (Exception w)
            {
                throw w;
            }

            return rlist;
        }

        private bool ValidateAlbum(Album a)
         {
             bool flag = true;
             StringBuilder sb = new StringBuilder();
             if (a.AlbumID < 1000)
             {
                 flag = false;
                 sb.Append("\nAlbum ID is Invalid");
             }

             if (a.AlbumName == string.Empty)
             {
                 flag = false;
                 sb.Append("\nAlbum Name cant be Empty");
             }

             Regex r = new Regex("[a-zA-Z]*$");
             if (!(r.IsMatch(a.AlbumName)))
             {
                 flag = false;
                 sb.Append("\nOnly Characters Please");
             }

             if (a.Category == string.Empty)
             {
                 flag = false;
                 sb.Append("\nCategory Cant be empty");
             }

             if (!(r.IsMatch(a.Category)))
             {
                 flag = false;
                 sb.Append("\nOnly Characters Please");
             }

             if (a.Company == string.Empty)
             {
                 flag = false;
                 sb.Append("\nCompany Name can't be empty");
             }

             if (a.Language == string.Empty)
             {
                 flag = false;
                 sb.Append("\nLanguage cant be empty");
             }

             if (a.No_Of_Songs <=0)
             {
                 flag = false;
                 sb.Append("\nNo of Songs cant be Null");
             }
             if (a.No_Of_Songs <=0)
             {
                 flag = false;
                 sb.Append("\nNo of Songs cant be negative or Zero");
             }

             if (a.Price <=0 )
             {
                 flag = false;
                 sb.Append("\nPrice cant be negative");
             }

             if (a.ReleaseDate > DateTime.Now)
             {
                 flag = false;
                 sb.Append("\nRelease date invalid");
             }

             if (flag == false)
             {
                 throw new AlbumExceptions(sb.ToString());
             }

             return flag;
         }
    }
}
