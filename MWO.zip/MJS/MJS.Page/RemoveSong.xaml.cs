﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for RemoveSong.xaml
    /// </summary>
    public partial class RemoveSong : Window
    {
        public RemoveSong()
        {
            InitializeComponent();
        }

        private void btndelete_Click(object sender, RoutedEventArgs e)
        {
            if (txtsongid.Text !="")
            {
                SongsBL bobj = new SongsBL();
                int i = Convert.ToInt32(txtsongid.Text);
                bool flag = bobj.RemoveSongBySongId(i);
                if (flag)
                {
                    MessageBox.Show("Song Is Deleted");
                }
                else
                {
                    MessageBox.Show("Unable to Delete Song");
                }
            }
            else
            {
                MessageBox.Show("Please Enter Songs");
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
