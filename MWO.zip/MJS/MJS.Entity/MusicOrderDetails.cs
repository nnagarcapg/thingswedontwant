﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJS.Entity
{
    public class MusicOrderDetails
    {
        //MusicOrderID, AlbumID, UnitPrice, Qty, Discount, PaymentID, TotAmount

        #region Fields
        int musicOrderID;
        int albumID;
        decimal unitPrice;
        int qty;
        int discount;
        int paymentID;
        decimal totAmount;
        #endregion

        #region Properties
        public decimal TotAmount
        {
            get { return totAmount; }
            set { totAmount = value; }
        }

        public int PaymentID
        {
            get { return paymentID; }
            set { paymentID = value; }
        }

        public int Discount
        {
            get { return discount; }
            set { discount = value; }
        }

        public int Qty
        {
            get { return qty; }
            set { qty = value; }
        }

        public decimal UnitPrice
        {
            get { return unitPrice; }
            set { unitPrice = value; }
        }

        public int AlbumID
        {
            get { return albumID; }
            set { albumID = value; }
        }

        public int MusicOrderID
        {
            get { return musicOrderID; }
            set { musicOrderID = value; }
        }
        #endregion
    }
}
