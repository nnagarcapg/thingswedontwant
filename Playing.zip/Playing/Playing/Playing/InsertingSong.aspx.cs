﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data.SqlClient;
using System.IO;

namespace Playing
{
    public partial class InsertingSong : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnupload_Click(object sender, EventArgs e)
        {
            byte[] song;

            Stream str = FileUploadSongs.PostedFile.InputStream;
            BinaryReader br = new BinaryReader(str);
            song = br.ReadBytes((Int32)str.Length);

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            SqlCommand cmd = new SqlCommand("INSERT INTO Songs VALUES(@d)", con);
            cmd.Parameters.AddWithValue("@d", song);

            con.Open();
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r > 0)
                Label1.Text = "Success";
            else
                Label1.Text = "Failure";
        }
    }
}