﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.IO;

namespace Playing
{
    /// <summary>
    /// Summary description for SoundPlayer
    /// </summary>
    public class SoundPlayer : IHttpHandler
    {

        public void ProcessRequest(HttpContext context)
        {
            string id = context.Request.QueryString["SongID"].ToString();
            byte[] song = null;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            SqlCommand cmd = new SqlCommand("Select * from Songs WHERE SongID=@i", con);
            cmd.Parameters.AddWithValue("@i", id);

            con.Open();
            SqlDataAdapter adapter = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            adapter.Fill(dt);
            song = (byte[])dt.Rows[0][1];
            con.Close();

            context.Response.Clear();
            context.Response.Buffer = true;
            context.Response.ContentType ="audio/mpeg3";
            context.Response.BinaryWrite(song);
            context.Response.End();

        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}