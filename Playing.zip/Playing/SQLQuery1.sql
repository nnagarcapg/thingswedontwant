use NNPractice

CREATE TABLE Songs 
(
	SongID INT IDENTITY(1,1) PRIMARY KEY,
	Data VARBINARY(max)
)

DROP TABLE Songs

Select * from Songs