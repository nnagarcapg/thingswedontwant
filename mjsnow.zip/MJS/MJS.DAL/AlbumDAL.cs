﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;

namespace MJS.DAL
{
    public class AlbumDAL
    {
        //public static List<Album> albumList = new List<Album>(); //Initialising albumList

        public bool AddAlbum(Album a)//Working ok NN
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO MJS.Album VALUES(@id, @an, @ac, @anos, @ard, @aco, @ap, @al)", con);
                //AlbumID, AlbumName, Category, No_Of_Songs, Release Date, Company, Price, Language
                cmd.Parameters.AddWithValue("@id", a.AlbumID);
                cmd.Parameters.AddWithValue("@an", a.AlbumName);
                cmd.Parameters.AddWithValue("@ac", a.Category);
                cmd.Parameters.AddWithValue("@anos", a.No_Of_Songs);
                cmd.Parameters.AddWithValue("@ard", a.ReleaseDate);
                cmd.Parameters.AddWithValue("@aco", a.Company);
                cmd.Parameters.AddWithValue("@ap", a.Price);
                cmd.Parameters.AddWithValue("@al", a.Language);

                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();

                if (ra>0)
                {
                    flag = true;
                }
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
            return flag;
        }

        public List<Album> ShowAllAlbum() //Woking ok NN 
        {
            List<Album> getalbumList = new List<Album>();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

            try
            {
                SqlDataAdapter adap = new SqlDataAdapter("SELECT * FROM MJS.Album", con); //SqlAdapter to display 2 or more rows 
                //Making an Obejct of SqlCommandBuilder
                SqlCommandBuilder builder = new SqlCommandBuilder();
                //Making an object of DataTable for holding the whole Table
                DataTable dTable = new DataTable();
                //Filling Data into DataTable Object
                adap.Fill(dTable);

                foreach (DataRow row in dTable.Rows)
                {
                    Album obj = new Album();
                    obj.AlbumID = Convert.ToInt32(row[0]);
                    obj.AlbumName = Convert.ToString(row[1]);
                    obj.Category = Convert.ToString(row[2]);
                    obj.No_Of_Songs = Convert.ToInt32(row[3]);
                    obj.ReleaseDate = Convert.ToDateTime(row[4]);
                    obj.Company = Convert.ToString(row[5]);
                    obj.Price = Convert.ToDecimal(row[6]);
                    obj.Language = Convert.ToString(row[7]);

                    getalbumList.Add(obj);
                }
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
            return getalbumList;
        }
        
        //To Update Album Details except AlbumID
        public bool UpdateAlbum(Album eAlbm) //Wokring ok NN
        {
            bool flag = false;

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

            try
            {
                string q = "update MJS.Album set AlbumName=@albName, Category=@cat, NoOFSongs=@noSongs, ReleaseDate=@relDate, Company=@cmpny, Price=@price, Lang=@lang  where AlbumID=@albId"; //Query
                SqlCommand cmd = new SqlCommand(q, con);

                cmd.Parameters.AddWithValue("@albId", eAlbm.AlbumID);
                cmd.Parameters.Add(new SqlParameter("@albName", eAlbm.AlbumName));
                cmd.Parameters.Add(new SqlParameter("@cat", eAlbm.Category));
                cmd.Parameters.Add(new SqlParameter("@noSongs", eAlbm.No_Of_Songs));
                cmd.Parameters.Add(new SqlParameter("@relDate", eAlbm.ReleaseDate));
                cmd.Parameters.Add(new SqlParameter("@cmpny", eAlbm.Company));
                cmd.Parameters.Add(new SqlParameter("@price", eAlbm.Price));
                cmd.Parameters.Add(new SqlParameter("@lang", eAlbm.Language));

                con.Open();
                int r = cmd.ExecuteNonQuery(); //Executing Query; r-returns the no. of rows being updated
                con.Close();
                if (r > 0)
                    flag = true;
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
            
            return flag;
        }

        //Delete Album Details By AlbumID
        public bool DeleteAlbumById(int albId) //Wokring OK NN
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

            try
            {
                string q = "DELETE from MJS.Album where AlbumID = @id"; //Query
                SqlCommand cmd = new SqlCommand(q, con);

                cmd.Parameters.Add(new SqlParameter("@id", albId));

                con.Open();
                int r = cmd.ExecuteNonQuery(); //Executing Query; r-returns the no. of rows being inserted
                con.Close();
                if (r > 0)
                    flag = true;
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }

            return flag;
        }

        //Search Album By AlbumName
        public List<Album> SearchAlbumByName(string albName)//Working ok NN 
        {
            List<Album> albListByName = new List<Album>();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

            try
            {
                SqlCommand cmd = new SqlCommand("select * from MJS.Album where AlbumName = @n", con);

                cmd.Parameters.AddWithValue("@n", albName);

                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader(); //Executing Query; 
                if (sdr.HasRows)
                {
                    sdr.Read();
                    Album item = new Album();
                    item.AlbumID = sdr.GetInt32(0);
                    item.AlbumName = sdr.GetString(1);
                    item.Category = sdr.GetString(2);
                    item.No_Of_Songs = sdr.GetInt32(3);
                    item.ReleaseDate = sdr.GetDateTime(4);
                    item.Company = sdr.GetString(5);
                    item.Price = sdr.GetDecimal(6);
                    item.Language = sdr.GetString(7);

                    albListByName.Add(item);
                }
                con.Close();
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }

            return albListByName;
        }

        //Search Album By ReleasedYear
        public List<Album> SearchAlbumByYear(int albYear)//Working ok NN 
        {
            //Album yObj = new Album();
            List<Album> albListByYear = new List<Album>();

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);

            try
            {
                SqlCommand cmd = new SqlCommand("select * from MJS.Album where DATEPART(year,ReleaseDate) = @y", con);

                cmd.Parameters.AddWithValue("@y", albYear);

                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader(); //Executing Query
                while (sdr.Read())
                {
                    Album item = new Album();
                    item.AlbumID = sdr.GetInt32(0);
                    item.AlbumName = sdr.GetString(1);
                    item.Category = sdr.GetString(2);
                    item.No_Of_Songs = sdr.GetInt32(3);
                    item.ReleaseDate = sdr.GetDateTime(4);
                    item.Company = sdr.GetString(5);
                    item.Price = sdr.GetDecimal(6);
                    item.Language = sdr.GetString(7);

                    albListByYear.Add(item);
                }
                con.Close();
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
            
            return albListByYear;
        }
    }
}
