﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Configuration;//For App.config File cstring
using System.Data;
using MJS.Entity;
using MJS.DAL;

namespace MJS.BL
{
    public class MusicOrderDetailsBL
    {
        public List<MusicOrderDetails> ShowAll()
        {
            try
            {
                MusicOrderDetailsDAL obj = new MusicOrderDetailsDAL();
                return obj.ShowAll();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception w)
            {
                throw w;
            }
        }
    }
}
