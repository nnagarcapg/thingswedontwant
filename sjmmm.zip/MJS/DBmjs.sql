--use NNPractice
--use Mumbai13Training

--CREATE SCHEMA MJS --ok

--Creating Customer Table
--1								First Table to Be Created
CREATE TABLE MJS.Customer 
(
	CustomerID INT PRIMARY KEY,
	CustName VARCHAR(100),
	Addess VARCHAR(250),
	DOB DATE, --YYYY-MM-DD
	City VARCHAR(60),
	Pass VARCHAR(15) NOT NULL,
	MobileNo VARCHAR(12)
)--Work OK.

INSERT INTO MJS.Customer VALUES(1000,'Lavanya', 'TamilNadu', '04/18/1996', 'Chennai', 'lava18', 9546231783 )
INSERT INTO MJS.Customer VALUES(1001,'Anusha', 'AndhraPradesh', '06/17/1995', 'Rajahmundry', 'anu123', 9632147598 )
INSERT INTO MJS.Customer VALUES(1002,'ManojK', 'AndhraPradesh', '05/25/1996', 'Srikakulam', 'manoj05', 8654712398 )
Select * FROM MJS.Customer
Select * FROM MJS.Customer WHERE CustomerID = 1000
DELETE FROM MJS.Customer WHERE CustomerID = 1000
UPDATE MJS.Customer SET CustName='ABC',Addess='Address',DOB='06/10/1990',City='City-2',Pass='passwd',MobileNo=95478123569 where CustomerID=1000
drop table MJS.Customer 

--##STORED PROCEDURE##--

---Stored Procedure to Login Customer---
GO
CREATE PROCEDURE MJS.udp_loginCustomer(@eid int,@password varchar(15))
AS
BEGIN
	SELECT * FROM MJS.Customer where CustomerID=@eid and Pass=@password 
END
GO
---Execute Stored Procedure to Login Employee---
EXEC MJS.udp_loginCustomer 1000,'passwd'


--Stored Procedure to Search Customer---
GO
CREATE PROCEDURE MJS.udp_searchCustomer(@i int)
AS
BEGIN
SELECT * FROM MJS.Customer WHERE CustomerID = @i
END
GO
---Execute Stored Procedure to Search Customer---
EXEC MJS.udp_searchCustomer 1001


---Stored Procedure to Delete Customer---
GO
CREATE PROCEDURE MJS.udp_deleteCustomer(@i int)
AS
BEGIN
DELETE FROM MJS.Customer WHERE CustomerID = @i
END
GO
---Execute Stored Procedure to Delete Customer---
EXEC MJS.udp_deleteCustomer 1002


---Stored Procedure to Update Customer---
GO
CREATE PROCEDURE MJS.udp_updateCustomer(
@n VARCHAR(100),
@a VARCHAR(250),
@d DATE,
@c VARCHAR(60),
@p VARCHAR(15),
@m VARCHAR(12),
@i 	INT
)
AS
BEGIN
UPDATE MJS.Customer SET CustName=@n,Addess=@a,DOB=@d,City=@c,Pass=@p,MobileNo=@m where CustomerID=@i
END
GO

---Execute Stored Procedure to Update Customer---
EXEC MJS.udp_updateCustomer 'abc','addr','10/20/1990','city-2','passwd',9547851239,1000

--drop procedure MJS.udp_updateCustomer

---Stored Procedure to DisplayAll Customer---
GO
CREATE PROCEDURE MJS.udp_displayCustomer
AS
BEGIN
SELECT * FROM MJS.Customer 
END
GO
---Execute Stored Procedure to DisplayAll Customer---
EXEC MJS.udp_displayCustomer 

--##Store Procedure To Auto Generate CustomerId
GO
CREATE PROCEDURE MJS.udp_customeridauto
AS
BEGIN
	SELECT MAX(CustomerID)+1 FROM MJS.Customer
END
GO

Exec MJS.udp_customeridauto



--#############################################################################################################################################
--Creating Employee Table
--2							Second Table to Be Created
CREATE TABLE MJS.Employee
(
	EmployeeID INT PRIMARY KEY,
	EmpName VARCHAR(100),
	Addess VARCHAR(250),
	DOB DATE, --YYYY-MM-DD
	City VARCHAR(60),
	Pass VARCHAR(15) NOT NULL,
	MobileNo VARCHAR(12)
)--Works OK. No Need To enter PK. Mobile Takes 10 Digit Number.

INSERT INTO MJS.Employee VALUES(1000,'Nishant','Punjab', '1995-12-21', 'Ferozpur', 'nishant', 9874563210)
INSERT INTO MJS.Employee VALUES(1001,'Aditi','Maharashtra', '1995-10-02', 'NaviMumbai', 'adi02', 8541236987)
INSERT INTO MJS.Employee VALUES(1002,'Sidharth','TamilNadu', '1995-09-09', 'Chennai', 'sid09', 954781238)
SELECT * FROM MJS.Employee
DELETE FROM MJS.Employee WHERE EmployeeID = 1000
drop table MJS.Employee

--SET IDENTITY_INSERT Mumbai13Training.MJS.Employee OFF
--SET IDENTITY_INSERT Mumbai13Training.MJS.Employee ON

--##STORED PROCEDURE##--
--Creating Procedure
GO
CREATE PROCEDURE usp_MJSemployeeInsert
(
	@id INT,
	@n VARCHAR(100),
	@a VARCHAR(250),
	@dob DATE,
	@c VARCHAR(60),
	@p VARCHAR(15),
	@mn INT
)
AS
BEGIN
	IF(@id = NULL)
		BEGIN
			INSERT INTO MJS.Employee VALUES(@n, @a, @dob, @c, @p, @mn)
		END
	ELSE
		BEGIN
			SET IDENTITY_INSERT Mumbai13Training.MJS.Employee ON
			INSERT INTO MJS.Employee VALUES(@id, @n, @a, @dob, @c, @p, @mn)
			SET IDENTITY_INSERT Mumbai13Training.MJS.Employee OFf
		END
END
GO

GO
CREATE PROCEDURE MJS.udp_employeeautoid
AS
BEGIN
	SELECT MAX(EmployeeID)+1 FROM MJS.Employee
END
GO

exec MJS.udp_employeeautoid


---Stored Procedure to Login Employee---
GO
CREATE PROCEDURE MJS.udp_loginEmployee(@eid int,@password varchar(15))
AS
BEGIN
SELECT * FROM MJS.Employee where EmployeeID=@eid and Pass=@password 
END
GO
---Execute Stored Procedure to Login Employee---
EXEC MJS.udp_loginEmployee 1000,'passwd'

---Stored Procedure to Update Employee---
GO
CREATE PROCEDURE MJS.udp_updateEmployee(
@eid INT,
@ename VARCHAR(100),
@address VARCHAR(250),
@dob DATE,
@city VARCHAR(60),
@password VARCHAR(15),
@mobileno VARCHAR(12)
)
AS
BEGIN
UPDATE MJS.Employee SET EmpName=@ename,Addess=@address,DOB=@dob,City=@city,Pass=@password,MobileNo=@mobileno where  EmployeeId=@eid
END
GO

---Execute Stored Procedure to Update Employee---
EXEC MJS.udp_updateEmployee 1000,'abc','addr','10/20/1990','city-2','passwd',9547851239


--#############################################################################################################################################
--Creating Album Table
--3 						Third Table to Be Created
CREATE TABLE MJS.Album
(
	AlbumID INT PRIMARY KEY, 
	AlbumName VARCHAR(100),
	Category VARCHAR(15),
	NoOFSongs INT,
	ReleaseDate DATE,--YYYY-MM-DD
	Company VARCHAR(50),
	Price MONEY,
	Lang VARCHAR(30)
)--Works OK. No Need To enter PK.

INSERT INTO MJS.Album VALUES(1001,'Shreya Ghoshal', 'Melodies', 4, '2017-10-12', 'T-Series', 8000, 'Hindi')
INSERT INTO MJS.Album VALUES(1002,'Shreya','Melodies', 5, '2017-10-12', 'T-Series', 4000, 'Tamil')
INSERT INTO MJS.Album VALUES(1003,'Atif', 'Melodies', 7, '2017-10-12', 'T-Series', 1500, 'Telugu')
SELECT * FROM MJS.Album 
SELECT * FROM MJS.Songs
DELETE FROM MJS.Album WHERE AlbumID = 1002
drop table MJS.Album

--##Store Procedure to get Album by id
Go
Create Procedure MJS.udp_albumbyid
(
	@i int
)
AS
BEGIN
	Select * from MJS.Album Where AlbumId=@i
END
GO

Exec MJS.udp_albumbyid 1001

--###Store Procedure to generate id
GO
CREATE PROCEDURE MJS.udp_albumidauto
AS
BEGIN
	SELECT Max(AlbumID)+1 FROM MJS.Album 
END
GO
Exec MJS.udp_albumidauto


--##STORED PROCEDURE##--
---Stored Procedure to Display Album---
GO
CREATE PROCEDURE MJS.udp_displayalbum
AS
BEGIN
SELECT * FROM MJS.Album
END
GO
---Execute Stored Procedure to Display Album---
EXEC MJS.udp_displayalbum

---Stored Procedure to Update Album---
GO
CREATE PROCEDURE MJS.udp_updateAlbum(
@albId int,
@albName VARCHAR(100),
@cat VARCHAR(15),
@noSongs INT,
@relDate DATE,
@cmpny VARCHAR(50),
@price MONEY,
@lang VARCHAR(30)
)
AS
BEGIN
UPDATE MJS.Album SET AlbumName=@albName,Category=@cat,NoOFSongs=@noSongs,ReleaseDate=@relDate,Company=@cmpny,Price=@price,Lang=@lang where AlbumID=@albId
END
GO

---Execute Stored Procedure to Update Album---
EXEC MJS.udp_updateAlbum 1001,'abc','cat',5,'10/20/1990','cmpny-2',100,'english'


---Stored Procedure to Delete By AlbumID---
GO
CREATE PROCEDURE MJS.udp_deleteAlbum(@id int)
AS
BEGIN
DELETE FROM MJS.Album WHERE AlbumID = @id
END
GO
---Execute Stored Procedure to Delete By AlbumID---
EXEC MJS.udp_deleteAlbum 1001


---Stored Procedure to Search By AlbumName---
GO
CREATE PROCEDURE MJS.udp_searchAlbumName(@name VARCHAR(100))
AS
BEGIN
SELECT * FROM MJS.Album where AlbumName=@name
END
GO
---Execute Stored Procedure to Search By AlbumName---
EXEC MJS.udp_searchAlbumName Atif


---Stored Procedure to Search By Year---
GO
CREATE PROCEDURE MJS.udp_searchByYear(@year INT)
AS
BEGIN
SELECT * FROM MJS.Album where DATEPART(YYYY,ReleaseDate)=@year
END
GO
---Execute Stored Procedure to Search By AlbumName---
EXEC MJS.udp_searchByYear 2017

--#############################################################################################################################################
--Creating SONGS Table
--4 						Fourth Table to Be Created
CREATE TABLE MJS.Songs
(
	SongID INT PRIMARY KEY,
	SongName VARCHAR(50),
	Singer VARCHAR(50),
	Movie VARCHAR(50),
	ComposedBy VARCHAR(50),
	Actor VARCHAR(50),
	Actress VARCHAR(50),
	Lyrics VARCHAR(100),
	RYear INT,
	AlbumID INT FOREIGN KEY REFERENCES MJS.Album(AlbumID),
	Lang VARCHAR(30),
	spath IMAGE
)--Works OK. No need PK. RYear columns takes special insert query to only store years. FK in working but is accepting null values.

INSERT INTO MJS.Songs VALUES(1000,'Gana', 'Shreya', 'Fana', 'A.R.Rahman', 'Sharukan', 'Kajol', 'Sri', 2010, 1001, 'Hindi')
INSERT INTO MJS.Songs VALUES(1001,'Jaan', 'Fatil', 'OkJanu', 'SarifKhan', 'Shahid', 'Kareena', 'Khan', 2011, 1002, 'Telugu')
INSERT INTO MJS.Songs VALUES(1002,'Adaaru Adaaru', 'SPB', 'Mangatha', 'Ilayaraja', 'Ajith', 'Samantha', 'Vaali', 2009, 1001, 'Tamil')

SELECT * FROM MJS.Songs
DELETE FROM MJS.Songs WHERE SongID = 1002
drop table MJS.Songs

GO
CREATE PROCEDURE MJS.udp_songautoid
AS
BEGIN
	SELECT MAX(SongId)+1 FROM MJS.Songs
END
GO

exec MJS.udp_songautoid

--##STORED PROCEDURE##--

---Stored Procedure to Delete By SongID---
GO
CREATE PROCEDURE MJS.udp_deleteSongById(@i int)
AS
BEGIN
DELETE FROM MJS.Songs WHERE SongID = @i
END
GO
---Execute Stored Procedure to Delete By AlbumID---
EXEC MJS.udp_deleteSongById 1001


--###################################################################################################################################

CREATE TABLE MJS.PlaylistDetails
(
	PlaylistID INT Primary Key,
	CustomerID INT NOT NULL,
	PlaylistName NVARCHAR(20) UNIQUE
)

--INSERT INTO MJS.PlaylistDetails VALUES(1000, 1000, 'Demo')
--DELETE FROM MJS.PlaylistDetails WHERE PlaylistID=1001
SELECT * FROM MJS.PlaylistDetails
--SELECT * FROM MJS.DemoTwo

--CREATE PROCEDURE Experiment
--(
--	@pn VARCHAR(max)
--)
--AS
--BEGIN
--END

DROP TABLE MJS.PlaylistDetails

--DROP TABLE MJS.SeeWell
--This is the base table for copying the structure to newly playlist

CREATE TABLE MJS.BasePlaylist
(
	SongID INT PRIMARY KEY, 
	SongName VARCHAR(MAX)
)
SELECT * FROM MJS.BasePlaylist

--####STORE PROCEDURE TO CREATE PLAYLIST FOR PARTICULER USER
CREATE PROCEDURE MJS.udp_createplaylist
(
	@id INT,
	@pn NVARCHAR(50)
)
AS
BEGIN
	DECLARE @aid INT, @sqlcmd NVARCHAR(max)
	BEGIN
		SELECT @aid=MAX(PlaylistID)+1 FROM MJS.PlaylistDetails
		INSERT INTO MJS.PlaylistDetails VALUES(@aid, @id, @pn)
	END
	IF EXISTS(SELECT * FROM MJS.PlaylistDetails WHERE PlaylistID=@aid)
		BEGIN
			SET @sqlcmd=N'SELECT * INTO MJS.' + @pn + ' FROM MJS.BasePlaylist'
			EXEC sp_executesql @sqlcmd
		END
END

--DROP PROCEDURE MJS.udp_createplaylist
--Exec MJS.udp_createplaylist 100,'Demo'

CREATE PROCEDURE ExperimentsIP
(
	@id INT,
	@sn VARCHAR(max),
	@pn VARCHAR(max)
)
AS
BEGIN
	DECLARE @sqlcmd NVARCHAR(MAX), @nid NVARCHAR(MAX), @nsn NVARCHAR(MAX), @npn NVARCHAR(MAX)
	SET @nid=CONVERT(NVARCHAR, @id)
	SET @nsn=CONVERT(NVARCHAR, @sn)
	SET @npn=CONVERT(NVARCHAR, @pn)

	BEGIN
		SET @sqlcmd='INSERT INTO MJS.'+@npn+'(SongID, SongName) VALUES('+@nid+','+@nsn+')'
		Exec sp_executesql @sqlcmd
	END	
END
SELECT * FROM MJS.BasePlaylist
EXEC ExperimentsIP 1000, 'HellOYeah', 'BasePlaylist'
DROP PROCEDURE ExperimentsIP


DECLARE @itbln NVARCHAR(max)
DECLARE @oop NVARCHAR(max), @nnm NVARCHAR(MAX) 
DECLARE @sqlcmdd NVARCHAR(MAX)
SET @itbln='MJS.BasePlaylist'
SET @oop=CONVERT(NVARCHAR, )
SET @sqlcmdd='INSERT INTO ' +@itbln+' VALUES('', ''OH Yeah'')'
EXEC sp_executesql @sqlcmdd


--#############################################################################################################################################
--Creating MusicOrder Table
--5 						Fifth Table to Be Created
CREATE TABLE MJS.MusicOrder
(
	OrderID INT PRIMARY KEY,
	OrderDate DATE,
	DeliveryDate DATE,
	OrdPaymentID INT,
	EmployeeID INT FOREIGN KEY REFERENCES MJS.Employee(EmployeeID),
	CustomerID INT FOREIGN KEY REFERENCES MJS.Customer(CustomerID)
)--Wokrs Ok. No need to enter PK. Date Columns cancel out time part automatically. FK References Works. Have to do something about OrdPymentID.

INSERT INTO MJS.MusicOrder VALUES(1000,GETDATE(), GETDATE(), 1000, 1000,1001)
INSERT INTO MJS.MusicOrder VALUES(1001,GETDATE(), GETDATE(), 1001, 1001,1000)
INSERT INTO MJS.MusicOrder VALUES(1002,GETDATE(), GETDATE(), 1002, 1002,1002)
SELECT * FROM MJS.MusicOrder
DELETE FROM MJS.MusicOrder WHERE OrderID=1002
drop table MJS.MusicOrder  

--##STORED PROCEDURE##--

---Stored Procedure to Delete  MusicOrder---
GO
CREATE PROCEDURE MJS.udp_deleteMusicOrder(@oi int)
AS
BEGIN
DELETE FROM MJS.MusicOrder WHERE OrderID = @oi
END
GO
---Execute Stored Procedure to Delete By AlbumID---
EXEC MJS.udp_deleteMusicOrder 1001


---Stored Procedure to Update MusicOrder---
GO
CREATE PROCEDURE MJS.udp_updateMusicOrder(
@oi INT,
@od DATE,
@dd DATE,
@opi INT,
@ei INT,
@ci INT
)
AS
BEGIN
UPDATE MJS.MusicOrder SET OrderDate=@od,DeliveryDate=@dd,OrdPaymentID=@opi,EmployeeID=@ei,CustomerID=@ci where OrderID=@oi
END
GO

---Execute Stored Procedure to Update Album---
EXEC MJS.udp_updateMusicOrder 1000,'02/25/2012','06/28/2010',1005,1002,1000

--#############################################################################################################################################
--Creating Payment Table
--6 						Sixth Table to Be Created
CREATE TABLE MJS.Payment
(
	PaymentID INT PRIMARY KEY,
	PayAccName VARCHAR(100),
	PayOrderID INT FOREIGN KEY REFERENCES MJS.MusicOrder(OrderID),
	PaymentDate DATE,
	Amount Money,
	PaymentMethod VARCHAR(20)
)--Works OK.

INSERT INTO MJS.Payment VALUES(1000,'Aditi', 1002, '2018-12-12', 8000, 'Net Banking')
INSERT INTO MJS.Payment VALUES(1001,'Lavanya', 1000, '2010-10-02', 7000, 'Debit Card')
INSERT INTO MJS.Payment VALUES(1002,'ManojK', 1000, '2015-05-10', 6000, 'Credit Card')
SELECT * FROM MJS.Payment
DELETE FROM MJS.Payment WHERE PaymentID=1000
drop table MJS.Payment

--#############################################################################################################################################
--Creating MusicOrderDetails Table
--7 						Seventh Table to Be Created
CREATE TABLE MJS.MusicOrderDetails
(
	MusicOrderID INT FOREIGN KEY REFERENCES MJS.MusicOrder(OrderID) NOT NULL,
	AlbumID INT FOREIGN KEY REFERENCES MJS.Album(AlbumID),
	UnitPrice MONEY,
	Qty INT,
	Discount INT,
	PaymentID INT FOREIGN KEY REFERENCES MJS.Payment(PaymentID),
	TotAmount AS ((UnitPrice*Qty)*Discount) --PERSISTED
)

INSERT INTO MJS.MusicOrderDetails VALUES(1000, 1002, 80,2,10, 1000)
INSERT INTO MJS.MusicOrderDetails VALUES(1000, 1001, 50,5,10, 1000)
INSERT INTO MJS.MusicOrderDetails VALUES(1002, 1001, 90,3,10, 1000)
SELECT * FROM MJS.MusicOrderDetails
DELETE FROM MJS.MusicOrderDetails WHERE MusicOrderID=1002
drop table MJS.MusicOrderDetails  

--##STORED PROCEDURE##--
---Stored Procedure to Display MusicOrderDetails---
GO
CREATE PROCEDURE MJS.udp_displayMusicOrderDetails
AS
BEGIN
SELECT * FROM MJS.MusicOrderDetails
END
GO
---Execute Stored Procedure to Display MusicOrderDetails---
EXEC MJS.udp_displayMusicOrderDetails



--#############################################################################################################################################
--Creating Storing Procedure
--1
GO
CREATE PROCEDURE usp_MJSMusicOrder
(
	@od DATE,
	@dd DATE,
	@ei INT,
	@ci INT,
	@moi INT,
		
)
AS
BEGIN

END
GO

CREATE TABLE MJS.Audio (sngid INT PRIMARY KEY, SName VARCHAR(50), SPath image)
DROP TABLE MJS.Audio
DELETE FROM MJS.Audio
SELECT * FROM MJS.Audio