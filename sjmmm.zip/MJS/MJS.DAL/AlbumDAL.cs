﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;//For Entities

namespace MJS.DAL
{
    public class AlbumDAL
    {
        //Class Level Connection Object
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
        //Class Level Command Object
        SqlCommand cmd = new SqlCommand();

        /// <summary>
        /// Function to Add Album
        /// </summary>
        /// <param name="a">It Takes a Object type parameter of Album Class</param>
        /// <returns>A bool value</returns>
        public bool AddAlbum(Album a)//Working ok NN
        {
            bool flag = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_addAlbum";
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@id", a.AlbumID);
                cmd.Parameters.AddWithValue("@an", a.AlbumName);
                cmd.Parameters.AddWithValue("@ac", a.Category);
                cmd.Parameters.AddWithValue("@anos", a.No_Of_Songs);
                cmd.Parameters.AddWithValue("@ard", a.ReleaseDate);
                cmd.Parameters.AddWithValue("@aco", a.Company);
                cmd.Parameters.AddWithValue("@ap", a.Price);
                cmd.Parameters.AddWithValue("@al", a.Language);

                con.Open();
                int ra = cmd.ExecuteNonQuery();
                con.Close();

                if (ra>0)
                {
                    flag = true;
                }
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return flag;
        }

        public List<Album> ShowAllAlbum() //Woking ok NN 
        {
            List<Album> getalbumList = new List<Album>();
            try
            {
                SqlDataAdapter adap = new SqlDataAdapter("MJS.udp_displayalbum", con); //SqlAdapter to display 2 or more rows 
                adap.SelectCommand.CommandType = CommandType.StoredProcedure;
                //Making an object of DataTable for holding the whole Table
                DataTable dTable = new DataTable();
                //Filling Data into DataTable Object
                adap.Fill(dTable);

                foreach (DataRow row in dTable.Rows)
                {
                    Album obj = new Album();
                    obj.AlbumID = Convert.ToInt32(row[0]);
                    obj.AlbumName = Convert.ToString(row[1]);
                    obj.Category = Convert.ToString(row[2]);
                    obj.No_Of_Songs = Convert.ToInt32(row[3]);
                    obj.ReleaseDate = Convert.ToDateTime(row[4]);
                    obj.Company = Convert.ToString(row[5]);
                    obj.Price = Convert.ToDecimal(row[6]);
                    obj.Language = Convert.ToString(row[7]);

                    getalbumList.Add(obj);
                }
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return getalbumList;
        }

        public int AutoGenAlbumId()//working ok NN
        {
            int id=0;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_albumidauto";
                cmd.Connection = con;

                con.Open();
                id = (int)cmd.ExecuteScalar();
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return id;
        }

        public Album ShowAlbumById(int id)//Working ok NN
        {
            Album item = new Album();
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_albumbyid";
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    item.AlbumID = dr.GetInt32(0);
                    item.AlbumName = dr.GetString(1);
                    item.Category = dr.GetString(2);
                    item.No_Of_Songs = dr.GetInt32(3);
                    item.ReleaseDate = dr.GetDateTime(4);
                    item.Company = dr.GetString(5);
                    item.Price = dr.GetDecimal(6);
                    item.Language = dr.GetString(7);
                }
                con.Close();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return item;
        }
        
        //To Update Album Details except AlbumID
        public bool UpdateAlbum(Album eAlbm) //Wokring ok NN
        {
            bool flag = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_updateAlbum";
                cmd.Connection = con;
                
                cmd.Parameters.AddWithValue("@albId", eAlbm.AlbumID);
                cmd.Parameters.AddWithValue("@albName", eAlbm.AlbumName);
                cmd.Parameters.AddWithValue("@cat", eAlbm.Category);
                cmd.Parameters.AddWithValue("@noSongs", eAlbm.No_Of_Songs);
                cmd.Parameters.AddWithValue("@relDate", eAlbm.ReleaseDate);
                cmd.Parameters.AddWithValue("@cmpny", eAlbm.Company);
                cmd.Parameters.AddWithValue("@price", eAlbm.Price);
                cmd.Parameters.AddWithValue("@lang", eAlbm.Language);

                con.Open();
                int r = cmd.ExecuteNonQuery(); //Executing Query; r-returns the no. of rows being updated
                con.Close();
                if (r > 0)
                    flag = true;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            
            return flag;
        }

        //Delete Album Details By AlbumID
        public bool DeleteAlbumById(int albId) //Wokring OK NN
        {
            bool flag = false;
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_deleteAlbum";
                cmd.Connection = con;
                cmd.Parameters.Add(new SqlParameter("@id", albId));

                con.Open();
                int r = cmd.ExecuteNonQuery(); //Executing Query; r-returns the no. of rows being inserted
                con.Close();
                if (r > 0)
                    flag = true;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }

            return flag;
        }

        //Search Album By AlbumName
        public List<Album> SearchAlbumByName(string albName)//Working ok NN 
        {
            List<Album> albListByName = new List<Album>();
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchAlbumName";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@name", albName);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader(); //Executing Query; 
                if (dr.HasRows)
                {
                    dr.Read();
                    Album item = new Album();
                    item.AlbumID = dr.GetInt32(0);
                    item.AlbumName = dr.GetString(1);
                    item.Category = dr.GetString(2);
                    item.No_Of_Songs = dr.GetInt32(3);
                    item.ReleaseDate = dr.GetDateTime(4);
                    item.Company = dr.GetString(5);
                    item.Price = dr.GetDecimal(6);
                    item.Language = dr.GetString(7);

                    albListByName.Add(item);
                }
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }

            return albListByName;
        }

        //Search Album By ReleasedYear
        public List<Album> SearchAlbumByYear(int albYear)//Working ok NN 
        {
            //Album yObj = new Album();
            List<Album> albListByYear = new List<Album>();
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchByYear";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@year", albYear);

                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader(); //Executing Query
                while (sdr.Read())
                {
                    Album item = new Album();
                    item.AlbumID = sdr.GetInt32(0);
                    item.AlbumName = sdr.GetString(1);
                    item.Category = sdr.GetString(2);
                    item.No_Of_Songs = sdr.GetInt32(3);
                    item.ReleaseDate = sdr.GetDateTime(4);
                    item.Company = sdr.GetString(5);
                    item.Price = sdr.GetDecimal(6);
                    item.Language = sdr.GetString(7);

                    albListByYear.Add(item);
                }
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            
            return albListByYear;
        }
    }
}
