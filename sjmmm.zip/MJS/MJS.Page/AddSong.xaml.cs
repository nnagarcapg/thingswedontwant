﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using WMPLib;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for AddSong.xaml
    /// </summary>
    public partial class AddSong : Window
    {
        Microsoft.Win32.OpenFileDialog f = new Microsoft.Win32.OpenFileDialog();//For File Open Dialog Box
        public AddSong()
        {
            InitializeComponent();
        }

        private void btnaddsong_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SongsBL obj = new SongsBL();
                Songs so = new Songs();

                so.Actor = txtactor.Text;
                so.Actress = txtacctress.Text;
                so.AlbumID = Convert.ToInt32(txtalbumid.Text);
                so.ComposedBy = txtcomposed.Text;
                so.Language = txtlanguage.Text;
                so.Lyrics = txtlyrics.Text;
                so.Movie = txtmovie.Text;
                so.Singer = txtsinger.Text;
                so.SongName = txtsongname.Text;
                so.SongsID = Convert.ToInt32(txtsongid.Text);
                so.Year = Convert.ToInt32(txtyear.Text);
                so.SPath = txtsongpath.Text;

                bool flag = obj.UploadSong(so);
                if (flag)
                {
                    MessageBox.Show("Song Uploaded");
                }
                else
                {
                    MessageBox.Show("Unable to Upload song");
                }
            }
            catch (SongsExceptions ses)
            {
                MessageBox.Show(ses.Message.ToString());
            }
            catch (SqlException v)
            {
                MessageBox.Show(v.Message.ToString());
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message.ToString());
            }
        }

        private void btnbrowse_Click(object sender, RoutedEventArgs e)
        {
            f.DefaultExt = ".mp3";
            Nullable<bool> a = f.ShowDialog();
            if (a == true)
            {
                txtsongpath.Text = f.FileName.ToString();
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
