﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for AddCustomer.xaml
    /// </summary>
    public partial class AddCustomer : Window
    {
        public AddCustomer()
        {
            InitializeComponent();
        }

        private void btnregister_Click(object sender, RoutedEventArgs e)//?OK
        {
            try
            {
                CustomerBL obj = new CustomerBL();

                    Customer o = new Customer();
                    o.CustomerID = Convert.ToInt32(txtid.Text);
                    o.CustName = txtname.Text;
                    o.Address = txtaddress.Text;
                    o.City = txtcity.Text;
                    o.DOB = Convert.ToDateTime(txtdob.Text);
                    o.Password = txtpassword.Text;
                    o.MobileNo = txtmobileno.Text;
                    bool flag = obj.AddCustomer(o);
                    if (flag)
                    {
                        MessageBox.Show("Customer added...");
                    }
                    else
                    {
                        MessageBox.Show("Unable to add Customer");
                    }
            }
            catch (CustomerException k)
            {
                MessageBox.Show(k.Message.ToString());
            }
            catch (SqlException v)
            {
                MessageBox.Show(v.Message.ToString());
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message.ToString());
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
