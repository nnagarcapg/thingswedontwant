﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class AdminMaster : System.Web.UI.MasterPage
    {
        List<string> songs = null;
        List<string> album = null; 
        List<string> cust = null;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                
            }
        }

        protected void ddladminsearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            songs = new List<string> { "All" , "Singer", "Movie", "Composed By", "Actor", "Actress", "Year", "Language" };
            album = new List<string> { "All", "Name", "Year" };
            cust = new List<string> {"Id","All" };

            switch (ddladminsearch.SelectedIndex)
            {
                case 0:
                    ddladminby.DataSource = songs ;
                    ddladminby.DataBind();
                    break;

                case 1:
                    ddladminby.DataSource = album ;
                    ddladminby.DataBind();
                    break;

                case 2:
                    ddladminby.DataSource = cust ;
                    ddladminby.DataBind();
                    break;

                default:
                    break;
            }
        }

        protected void Visibility(int i)
        {
            if (i == 0)
            {
                gdvcustomers.Visible = false;
                gdvalbums.Visible = false;
                gdvsongs.Visible = true;
            }

            else if (i ==1)
            {
                gdvcustomers.Visible = false;
                gdvsongs.Visible = false;
                gdvalbums.Visible = true;
            }

            else if (i == 2)
            {
                gdvsongs.Visible = false;
                gdvalbums.Visible = false;
                gdvcustomers.Visible = true;
            }
        }

        protected void btnadminsearch_Click(object sender, EventArgs e)
        {
            SongsBL sbobj = new SongsBL();
            AlbumBL abobj = new AlbumBL();
            CustomerBL cbobj = new CustomerBL();
            switch (ddladminsearch.SelectedIndex)
            {
                case 0:
                    switch (ddladminby.SelectedIndex)
                    {
                        case 0:
                            Visibility(0);
                            gdvsongs.DataSource = sbobj.ShowAllSongs();
                            break;

                        case 1:
                            Visibility(0);
                            gdvsongs.DataSource = sbobj.SearchSongBySinger(txtadminsearch.Text);
                            break;

                        case 2:
                            Visibility(0);
                            gdvsongs.DataSource = sbobj.SearchSongByMovie(txtadminsearch.Text);
                            break;

                        case 3:
                            Visibility(0);
                            gdvsongs.DataSource = sbobj.SearchSongByComposer(txtadminsearch.Text);
                            break;

                        case 4:
                            Visibility(0);
                            gdvsongs.DataSource = sbobj.SearchSongByActor(txtadminsearch.Text);
                            break;

                        case 5:
                            Visibility(0);
                            gdvsongs.DataSource = sbobj.SearchSongByActress(txtadminsearch.Text);
                            break;

                        case 6:
                            Visibility(0);
                            gdvsongs.DataSource = sbobj.SearchSongByYear(Convert.ToInt32(txtadminsearch.Text));
                            break;

                        case 7:
                            Visibility(0);
                            gdvsongs.DataSource = sbobj.SearchSongByLanguage(txtadminsearch.Text);
                            break;
                    }
                    gdvsongs.DataBind();
                    break;

                case 1:
                    switch (ddladminby.SelectedIndex)
	                {
                        case 0:
                            Visibility(1);
                            gdvalbums.DataSource = abobj.ShowAllAlbum();
                            break;

                        case 1:
                            Visibility(1);
                            gdvalbums.DataSource = abobj.SearchAlbumByName(txtadminsearch.Text);
                            break;

                        case 2:
                            Visibility(1);
                            gdvalbums.DataSource = abobj.SearchAlbumByYear(Convert.ToInt32(txtadminsearch.Text));
                            break;
	                }
                    gdvalbums.DataBind();
                    break;

                case 2:
                    switch (ddladminby.SelectedIndex)
	                {
                        case 0:
                            Visibility(2);
                            gdvcustomers.DataSource = cbobj.SearchCustomerById(Convert.ToInt32(txtadminsearch.Text));
                            break;

                        case 1:
                            Visibility(2);
                            gdvcustomers.DataSource = cbobj.DisplayCustomer();
                            break;
	                }
                    gdvcustomers.DataBind();
                    break;

                default:
                    break;
            }
        }
    }
}