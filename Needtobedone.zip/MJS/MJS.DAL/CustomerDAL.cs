﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;

namespace MJS.DAL
{
    public class CustomerDAL
    {
        //Class Level Connection Object
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
        //Class Level Command Object
        SqlCommand cmd = new SqlCommand();

        public bool LoginCredentials(Customer rec)//OK -
        {
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_loginCustomer";
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@eid", rec.CustomerID);
                cmd.Parameters.AddWithValue("@password", rec.Password);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                bool flag = dr.HasRows;
                con.Close();
                if (flag)
                    return true;
                else
                   return false;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }

        public bool AddCustomer(Customer c)
        {
            bool flag = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_addCust";
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@i", c.CustomerID);
                cmd.Parameters.AddWithValue("@n", c.CustName);
                cmd.Parameters.AddWithValue("@a", c.Address);
                cmd.Parameters.AddWithValue("@d", c.DOB);
                cmd.Parameters.AddWithValue("@c", c.City);
                cmd.Parameters.AddWithValue("@p", c.Password);
                cmd.Parameters.AddWithValue("@m", c.MobileNo);
                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                    flag = true;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return flag;
        }

        public int AutoGenCustomerId()
        {
            int id = 0;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_customeridauto";
                cmd.Connection = con;

                con.Open();
                id = (int)cmd.ExecuteScalar();
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return id;
        }

        public Customer SearchCustomerById(int id)
        {
            Customer c = new Customer();
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchCustomer";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@i", id);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    c.CustomerID = Convert.ToInt32(dr[0]);
                    c.CustName = dr[1].ToString();
                    c.Address = dr[2].ToString();
                    c.DOB = Convert.ToDateTime(dr[3]);
                    c.City = dr[4].ToString();
                    c.Password = dr[5].ToString();
                    c.MobileNo = dr[6].ToString();
                }
                dr.Close();
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return c;
        }

        public bool RemoveCustomer(int id)
        {
            bool flag = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_deleteCustomer";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@i", id);
                con.Open();
                int r = cmd.ExecuteNonQuery();
                con.Close();
                if (r > 0)
                    flag = true;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return flag;
        }

        public bool UpdateCustomer(Customer c)
        {
            bool flag = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_updateCustomer";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@i", c.CustomerID);
                cmd.Parameters.AddWithValue("@n", c.CustName);
                cmd.Parameters.AddWithValue("@a", c.Address);
                cmd.Parameters.AddWithValue("@d", c.DOB);
                cmd.Parameters.AddWithValue("@c", c.City);
                cmd.Parameters.AddWithValue("@p", c.Password);
                cmd.Parameters.AddWithValue("@m", c.MobileNo);

                con.Open();
                int r = cmd.ExecuteNonQuery();
                con.Close();
                if (r > 0)
                    flag = true;
            
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return flag;
        }

        public List<Customer> DisplayCustomer()
        {
            List<Customer> custList = new List<Customer>();
            try
            {
                SqlDataAdapter adap = new SqlDataAdapter("MJS.udp_displayCustomer", con);
                adap.SelectCommand.CommandType = CommandType.StoredProcedure;

                DataTable dTable = new DataTable();
                adap.Fill(dTable);

                foreach (DataRow row in dTable.Rows)
                {
                    Customer obj = new Customer();
                    obj.CustomerID = Convert.ToInt32(row[0]);
                    obj.CustName = Convert.ToString(row[1]);
                    obj.Address = Convert.ToString(row[2]);
                    obj.DOB = Convert.ToDateTime(row[3]);
                    obj.City = Convert.ToString(row[4]);
                    obj.Password = Convert.ToString(row[5]);
                    obj.MobileNo = Convert.ToString(row[6]);

                    custList.Add(obj);
                }
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return custList;
        }
    }
}
