﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class UserMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //if (!Page.IsPostBack)
            //{
            //    SongsBL sbobj = new SongsBL();
            //    gdvsongs.DataSource = sbobj.ShowAllSongs();
            //    gdvsongs.DataBind();
            //}
        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            //Code For User search thing
            //gdvsongs.Visible = true;
        }
    }
}