﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for RemoveCustomer.xaml
    /// </summary>
    public partial class RemoveCustomer : Window
    {
        public RemoveCustomer()
        {
            InitializeComponent();
        }

        private void btnremove_Click_1(object sender, RoutedEventArgs e)
        {
            if (txtid.Text != "")
            {
                try
                {
                    CustomerBL cbo = new CustomerBL();
                    int id = Convert.ToInt32(txtid.Text);
                    bool flag = cbo.RemoveCustomer(id);
                    if (flag)
                    {
                        MessageBox.Show("Customer with ID: " + id + " is Deleted ");
                    }
                    else
                    {
                        MessageBox.Show("Unable to Remove Customer");
                    }
                }
                catch (ValueUnavailableException vue)
                {
                    MessageBox.Show(vue.Message.ToString());
                }
                catch (SqlException se)
                {
                    MessageBox.Show(se.Message.ToString());
                }
                catch (Exception f)
                {
                    MessageBox.Show(f.Message.ToString());
                }
            }
            else
            {
                MessageBox.Show("Please Enter Customer ID: ");
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
