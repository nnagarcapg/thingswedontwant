﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Text.RegularExpressions;
using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.DAL;

namespace MJS.BL
{
    public class MusicOrderBL
    {
        public List<MusicOrder> SearchMusicOrder(int OrderId)
        {
            List<MusicOrder> retList = null;
            try
            {
                MusicOrderDAL obj = new MusicOrderDAL();
                retList = obj.SearchMusicOrder(OrderId);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }

            return retList;
        }

        public bool DeleteOrder(int OrderId)
        {
            bool flag = false;
            try
            {
                MusicOrderDAL obj = new MusicOrderDAL();
                flag = obj.DeleteOrder(OrderId);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return flag;
        }

        public bool UpdateOrder(MusicOrder Mo)
        {
            bool flag = false;
            try
            {
                MusicOrderDAL obj = new MusicOrderDAL();
                flag = obj.UpdateOrder(Mo);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return flag;
        }

        public bool AddOrder(MusicOrder Mo)
        {
            bool flag = false;
            try
            {
                if (ValidateMusiceOrder(Mo))
                {
                    MusicOrderDAL obj = new MusicOrderDAL();
                    flag = obj.AddOrder(Mo);
                }
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }

            return flag;
        }

        private bool ValidateMusiceOrder(MusicOrder m)
        {
            bool flag = true;
            StringBuilder sb = new StringBuilder();
            if (m.CustomerID <1000)
            {
                flag = false;
                sb.Append("\nPlease: Invalid CustomerID");
            }

            if (m.EmployeeID <1000)
            {
                flag = false;
                sb.Append("\nPlease: Invalid EmployeeID");
            }

            if (m.OrderID <1000)
            {
                flag = false;
                sb.Append("\nPlease: Invalid OrderID");
            }

            if (m.OrdPaymentID <1000)
            {
                flag = false;
                sb.Append("\nPlease: Invalid Order Payment");
            }

            if (m.OrderDate < DateTime.Today)
            {
                flag = false;
                sb.Append("\nPlease: Invalid Order Date"); 
            }

            if (m.DeliveryDate <DateTime.Today)
            {
                flag = false;
                sb.Append("\nPlease: Invalid Delivery Date");
            }

            if (flag == false)
            {
                throw new MusicOrderExceptions(sb.ToString());
            }

            return flag;
        }
    }
}
