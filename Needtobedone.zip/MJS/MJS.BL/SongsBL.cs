﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Text.RegularExpressions;
using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.DAL;

namespace MJS.BL
{
    public class SongsBL
    {
        //Class Level Object of Song DAL Class
        SongsDAL dobj = new SongsDAL();

        public int DownloadSong(int id)
        {
            try
            {
                return dobj.DownloadSong(id);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
        }

        public int AutoGenSongId()
        {
            try
            {
                return dobj.AutoGenSongId();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public bool RemoveSongBySongId(int songId)//
        {
            bool flag = false;
            try
            {
                flag = dobj.RemoveSongBySongId(songId);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return flag;
        }

        public bool UpdateSong(Songs s)//
        {
            bool flag = false;
            try
            {
                if (ValidateSong(s))
                {
                    flag = dobj.UpdateSong(s);
                }
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return flag;
        }

        public bool UploadSong(Songs s)//
        {
            bool flag = false;
            try
            {
                if (ValidateSong(s))
                {
                    flag = dobj.UploadSong(s);
                }
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return flag;
        }

        public List<Songs> SearchSongByComposer(string name)//
        {
            List<Songs> rlist = null;
            try
            {

            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return rlist;
        }

        public List<Songs> SearchSongBySinger(string singerName)//
        {
            List<Songs> rlist = null;
            try
            {
                rlist = dobj.SearchSongBySinger(singerName);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return rlist;
        }

        public List<Songs> SearchSongByLanguage(string langname)//
        {
            List<Songs> rlist = null;

            try
            {
                rlist = dobj.SearchSongByLanguage(langname);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }

            return rlist;
        }

        public List<Songs> SearchSongByActor(string actorName)//
        {
            List<Songs> rlist = null;

            try
            {
                rlist = dobj.SearchSongByActor(actorName);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }

            return rlist;
        }

        public List<Songs> SearchSongByActress(string actressName)//
        {
            List<Songs> rlist = null;

            try
            {
                rlist = dobj.SearchSongByActress(actressName);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }

            return rlist;
        }

        public List<Songs> SearchSongByYear(int year)//
        {
            List<Songs> rlist = null;

            try
            {
                rlist = dobj.SearchSongByYear(year);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }

            return rlist;
        }

        public List<Songs> SearchSongByMovie(string movieName)//
        {
            List<Songs> rlist = null;

            try
            {
                rlist = dobj.SearchSongByMovie(movieName);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }

            return rlist;
        }

        public List<Songs> ShowAllSongs()
        {
            try
            {
                return dobj.ShowAllSongs();
            }
            catch (Exception)
            {
                throw;
            }
        }

        private bool ValidateSong(Songs s)
        {
            bool flag = true;
            StringBuilder sb = new StringBuilder();
            if (s.SongsID < 1000)
            {
                flag = false;
                sb.Append("\nID cant be Negative");
            }

            if (s.SongName == string.Empty)
            {
                flag = false;
                sb.Append("\nName cant be empty");
            }

            if (s.Singer == string.Empty)
            {
                flag = false;
                sb.Append("\nSinger Name can't Empty");
            }

            if (s.Movie == string.Empty)
            {
                flag = false;
                sb.Append("\nMovie cant be empty");
            }

            if (s.Lyrics == string.Empty)
            {
                flag = false;
                sb.Append("\nLyrics cant be empty");
            }

            if (s.Year <= 1800 )
            {
                flag = false;
                sb.Append("\nYear Should be greater than 1900");
            }

            if (s.Language == string.Empty)
            {
                flag = false;
                sb.Append("\nLanguage cant be empty");
            }

            if (s.ComposedBy == string.Empty)
            {
                flag = false;
                sb.Append("\nComposer cant be empty");
            }

            if (s.AlbumID < 1000)
            {
                flag = false;
                sb.Append("\n Album id cant be negative");
            }

            if (s.Actress == string.Empty)
            {
                flag = false;
                sb.Append("\n Actress cant be empty");
            }

            if (s.Actor == string.Empty)
            {
                flag = false;
                sb.Append("\nActor cant be empty");
            }

            if (flag == false)
            {
                throw new SongsExceptions(sb.ToString());
            }

            return flag;
        }
    }
}
