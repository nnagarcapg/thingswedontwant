﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJS.Exceptions
{
        [Serializable]

    public class MusicOrderExceptions:ApplicationException
    {
        public MusicOrderExceptions(string message):base(message)
        {

        }
    }
}
