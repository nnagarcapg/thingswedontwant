﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class UpdateDetailss : System.Web.UI.Page
    {
        EmployeeBL ebobj = new EmployeeBL();
        int id=0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                id = Convert.ToInt32(Session["adminId"]);
                Show();
            }
        }

        private void Show()
        {
            lblerrormsg.Text = "";
            Employee cobj = ebobj.SearchEmployeeById(id);
            if (cobj.EmployeeID != 0)
            {
                txtadminid.Text = cobj.EmployeeID.ToString();
                txtadminname.Text = cobj.EmpName;
                txtaddress.Text = cobj.Address;
                txtcity.Text = cobj.City;
                txtdateofbirth.Text = cobj.DOB.ToString();
                txtmobileno.Text = cobj.MobileNo;
                txtpassword.Text = cobj.Password;
                txtconfirmpassword.Text = cobj.Password;

                txtadminid.Enabled = false;
            }
            else
            {
                lblerrormsg.ForeColor = System.Drawing.Color.Red;
                lblerrormsg.Text = "No Such Admin Exists";
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            try
            {
                Employee cobj = new Employee();
                cobj.Address = txtaddress.Text;
                cobj.City = txtcity.Text;
                cobj.EmpName = txtadminname.Text;
                cobj.EmployeeID = Convert.ToInt32(txtadminid.Text);
                cobj.DOB = Convert.ToDateTime(txtdateofbirth.Text);
                cobj.MobileNo = txtmobileno.Text;
                cobj.Password = txtpassword.Text;

                if (ebobj.UpdateEmployee(cobj))
                {
                    lblerrormsg.ForeColor = System.Drawing.Color.Green;
                    lblerrormsg.Text = "Updated successfully";
                }
                else
                {
                    lblerrormsg.ForeColor = System.Drawing.Color.Red;
                    lblerrormsg.Text = "Unable to Update";
                }
            }
            catch (EmployeeExceptions eexp)
            {
                lblerrormsg.Text = eexp.Message.ToString();
            }
            catch (SqlException cexp)
            {
                lblerrormsg.Text = cexp.Message.ToString();
            }
            catch (Exception exp)
            {
                lblerrormsg.Text = exp.Message.ToString();
            }
        }

        
    }
}