﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class AddCustomer : System.Web.UI.Page
    {
        //Class Level Object og Customer BL Layer
        CustomerBL cbobj = new CustomerBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                txtcustomerid.Text = cbobj.AutoGenCustomerId().ToString();
        }

        protected void btnaddcustomer_Click(object sender, EventArgs e)
        {
            try
            {
                Customer cobj = new Customer();
                cobj.Address = txtaddress.Text;
                cobj.City = txtcity.Text;
                cobj.CustName = txtcustomername.Text;
                cobj.CustomerID = Convert.ToInt32(txtcustomerid.Text);
                cobj.DOB = Convert.ToDateTime(txtdateofbirth.Text);
                cobj.MobileNo = txtmobileno.Text;
                cobj.Password = txtpassword.Text;

                if (cbobj.AddCustomer(cobj))
                {
                    lblerrormsg.ForeColor = System.Drawing.Color.Green;
                    lblerrormsg.Text = "Customer Added Successfully";
                }
                else
                {
                    lblerrormsg.ForeColor = System.Drawing.Color.Red;
                    lblerrormsg.Text = "Unable to Add Customer";
                }
            }
            catch (CustomerException cexp)
            {
                lblerrormsg.Text = cexp.Message.ToString();
            }
            catch (SqlException se)
            {
                lblerrormsg.Text = se.Message.ToString();
            }
            catch (Exception ex)
            {
                lblerrormsg.Text = ex.Message.ToString();
            }
        }
    }
}