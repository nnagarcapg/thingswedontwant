﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (rdbuserlist.SelectedIndex == 1)
            {
                EmployeeBL ebobj = new EmployeeBL();
                Employee eobj = new Employee();
                eobj.EmployeeID = Convert.ToInt32(txtid.Text);
                eobj.Password = txtpassword.Text;
                if (ebobj.LoginCredentials(eobj))
                {
                    Session["adminId"] = txtid.Text;
                    Response.Redirect("AdminHomePage.aspx");
                }
                else
                {
                    lblmsg.Text = "Login Credentials Invalid";
                }
            }
            else if(rdbuserlist.SelectedIndex == 0)
            {
                CustomerBL cbobj = new CustomerBL();
                Customer cobj = new Customer();
                cobj.CustomerID = Convert.ToInt32(txtid.Text);
                cobj.Password = txtpassword.Text;
                if (cbobj.LoginCredentials(cobj))
                {
                    Session["userId"] = txtid.Text;
                    Response.Redirect("UserHomePage.aspx");
                }
                else
                {
                    lblmsg.Text = "Login Credentials Invalid";
                }
            }
            else
            {
                lblmsg.Text = "Please Choose Your Login type";
            }
        }

    }
}