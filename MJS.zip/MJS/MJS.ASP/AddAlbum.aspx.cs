﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class AddAlbum : System.Web.UI.Page
    {
        //Class Level Object og Album BL Layer
        AlbumBL abobj = new AlbumBL();
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
                txtalbumid.Text = abobj.AutoGenAlbumId().ToString();
        }

        protected void btnaddalbum_Click(object sender, EventArgs e)
        {
            try
            {
                Album aobj = new Album();
                aobj.AlbumID = Convert.ToInt32(txtalbumid.Text);
                aobj.AlbumName = txtalbumname.Text;
                aobj.Category = txtcategory.Text;
                aobj.Company = txtcompany.Text;
                aobj.Language = txtlanguage.Text;
                aobj.No_Of_Songs = Convert.ToInt32(txtnoofsongs.Text);
                aobj.Price = Convert.ToDecimal(txtprice.Text);
                aobj.ReleaseDate = Convert.ToDateTime(txtreleasedate.Text);

                if (abobj.AddAlbum(aobj))
                {
                    lblerrormsg.ForeColor = System.Drawing.Color.Green;
                    lblerrormsg.Text = "Album Added Successfully";
                }
                else
                {
                    lblerrormsg.ForeColor = System.Drawing.Color.Red;
                    lblerrormsg.Text = "Unable to Add Album";
                }
                
            }
            catch (AlbumExceptions aexp)
            {
                lblerrormsg.Text = aexp.Message.ToString();
            }
            catch (SqlException se)
            {
                lblerrormsg.Text = se.Message.ToString();
            }
            catch (Exception v)
            {
                lblerrormsg.Text = v.Message.ToString();
            }
        }
    }
}