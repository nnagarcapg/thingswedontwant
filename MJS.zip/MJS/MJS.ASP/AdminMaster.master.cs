﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class AdminMaster : System.Web.UI.MasterPage
    {
        List<string> songs = null;
        List<string> album = null; 
        List<string> cust = null;

        SongsBL sbobj = new SongsBL();
        AlbumBL abobj = new AlbumBL();
        CustomerBL cbobj = new CustomerBL();
        

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Necessary();
            }
        }

        protected void Necessary()
        {
            Button btn = (Button)this.Master.FindControl("btnlogin");
            btn.Text = "Welcome: ";
            btn.Enabled = false;
            btn = (Button)this.Master.FindControl("btnregister");
            btn.Text = Session["adminId"].ToString();
            btn.Enabled = false;
        }

        protected void ddladminsearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            songs = new List<string> { "All" , "Singer", "Movie", "Composed By", "Actor", "Actress", "Year", "Language" };
            album = new List<string> { "All", "Name", "Year" };
            cust = new List<string> { "All", "Id" };

            switch (ddladminsearch.SelectedIndex)
            {
                case 0:
                    ddladminby.DataSource = songs;
                    ddladminby.DataBind();
                    break;

                case 1:
                    ddladminby.DataSource = album;
                    ddladminby.DataBind();
                    break;

                case 2:
                    ddladminby.DataSource = cust;
                    ddladminby.DataBind();
                    break;

                default:
                    break;
            }
        }

        protected void Visibility(int i)
        {
            if (i == 0)
            {
                gdvcustomers.Visible = false;
                gdvalbums.Visible = false;
                gdvsongs.Visible = true;
            }

            else if (i == 1)
            {
                gdvcustomers.Visible = false;
                gdvsongs.Visible = false;
                gdvalbums.Visible = true;
            }

            else if (i == 2)
            {
                gdvsongs.Visible = false;
                gdvalbums.Visible = false;
                gdvcustomers.Visible = true;
            }
        }

        protected void PopulateCustomer()
        {
            gdvcustomers.DataSource = cbobj.DisplayCustomer();
            gdvcustomers.DataBind();
        }

        protected void PopulateAlbum()
        {
            gdvalbums.DataSource = abobj.ShowAllAlbum();
            gdvalbums.DataBind();
        }

        protected void PopulateSongs()
        {
            gdvsongs.DataSource = sbobj.ShowAllSongs();
            gdvsongs.DataBind();
        }

        protected void btnadminsearch_Click(object sender, EventArgs e)
        {
            try
            {
                switch (ddladminsearch.SelectedIndex)
                {
                    case 0:
                        switch (ddladminby.SelectedIndex)
                        {
                            case 0:
                                Visibility(0);
                                gdvsongs.DataSource = sbobj.ShowAllSongs();
                                break;

                            case 1:
                                Visibility(0);
                                gdvsongs.DataSource = sbobj.SearchSongBySinger(txtadminsearch.Text);
                                break;

                            case 2:
                                Visibility(0);
                                gdvsongs.DataSource = sbobj.SearchSongByMovie(txtadminsearch.Text);
                                break;

                            case 3:
                                Visibility(0);
                                gdvsongs.DataSource = sbobj.SearchSongByComposer(txtadminsearch.Text);
                                break;

                            case 4:
                                Visibility(0);
                                gdvsongs.DataSource = sbobj.SearchSongByActor(txtadminsearch.Text);
                                break;

                            case 5:
                                Visibility(0);
                                gdvsongs.DataSource = sbobj.SearchSongByActress(txtadminsearch.Text);
                                break;

                            case 6:
                                Visibility(0);
                                gdvsongs.DataSource = sbobj.SearchSongByYear(Convert.ToInt32(txtadminsearch.Text));
                                break;

                            case 7:
                                Visibility(0);
                                gdvsongs.DataSource = sbobj.SearchSongByLanguage(txtadminsearch.Text);
                                break;
                        }
                        gdvsongs.DataBind();
                        break;

                    case 1:
                        switch (ddladminby.SelectedIndex)
	                    {
                            case 0:
                                Visibility(1);
                                gdvalbums.DataSource = abobj.ShowAllAlbum();
                                break;

                            case 1:
                                Visibility(1);
                                gdvalbums.DataSource = abobj.SearchAlbumByName(txtadminsearch.Text);
                                break;

                            case 2:
                                Visibility(1);
                                gdvalbums.DataSource = abobj.SearchAlbumByYear(Convert.ToInt32(txtadminsearch.Text));
                                break;
	                    }
                        gdvalbums.DataBind();
                        break;

                    case 2:
                        switch (ddladminby.SelectedIndex)
	                    {
                            case 0:
                                Visibility(2);
                                gdvcustomers.DataSource = cbobj.DisplayCustomer();
                                break;

                            case 1:
                                Visibility(2);
                                List<Customer> clist = new List<Customer>();
                                clist.Add(cbobj.SearchCustomerById(Convert.ToInt32(txtadminsearch.Text)));
                                gdvcustomers.DataSource = clist;
                                break;
	                    }
                        gdvcustomers.DataBind();
                        break;

                    default:
                        break;
                }
            }
            catch (Exception)
            {
                Response.Redirect("Errorpage.aspx");
            }
        }

        protected void gdvcustomers_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gdvcustomers.PageIndex = e.NewPageIndex;
            PopulateCustomer();
        }

        protected void gdvcustomers_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gdvcustomers.EditIndex = -1;
            PopulateCustomer();
        }

        protected void gdvcustomers_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gdvcustomers.EditIndex = e.NewEditIndex;
            PopulateCustomer();
        }

        protected void gdvcustomers_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Customer cobj = new Customer();
            TextBox tb = (TextBox)gdvcustomers.Rows[e.RowIndex].FindControl("txtcustomerid");
            cobj.CustomerID = Convert.ToInt32(tb.Text);

            tb = (TextBox)gdvcustomers.Rows[e.RowIndex].FindControl("txtcustname");
            cobj.CustName = tb.Text;

            tb = (TextBox)gdvcustomers.Rows[e.RowIndex].FindControl("txtaddress");
            cobj.Address = tb.Text;

            tb = (TextBox)gdvcustomers.Rows[e.RowIndex].FindControl("txtdob");
            cobj.DOB = Convert.ToDateTime(tb.Text);

            tb = (TextBox)gdvcustomers.Rows[e.RowIndex].FindControl("txtcity");
            cobj.City = tb.Text;

            tb = (TextBox)gdvcustomers.Rows[e.RowIndex].FindControl("txtpass");
            cobj.Password = tb.Text;

            tb = (TextBox)gdvcustomers.Rows[e.RowIndex].FindControl("txtmobileno");
            cobj.MobileNo = tb.Text;

            if (!cbobj.UpdateCustomer(cobj))
            {
                lblmsg.Text = "Error";
            }

            gdvcustomers.EditIndex = -1;
            PopulateCustomer();
        }

        protected void gdvcustomers_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label lb = (Label)gdvcustomers.Rows[e.RowIndex].FindControl("lblcustomerid");
            int id = Convert.ToInt32(lb.Text);
            cbobj.RemoveCustomer(id);

            gdvcustomers.EditIndex = -1;
            PopulateCustomer();
        }

        protected void gdvalbums_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gdvalbums.PageIndex = e.NewPageIndex;
            PopulateAlbum();
        }

        protected void gdvalbums_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gdvalbums.EditIndex = -1;
            PopulateAlbum();
        }

        protected void gdvalbums_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gdvalbums.EditIndex = e.NewEditIndex;
            PopulateAlbum();
        }

        protected void gdvalbums_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Album aobj = new Album();
            
            TextBox tb = (TextBox)gdvalbums.Rows[e.RowIndex].FindControl("txtalbumid");
            aobj.AlbumID = Convert.ToInt32(tb.Text);

            tb = (TextBox)gdvalbums.Rows[e.RowIndex].FindControl("txtalbumname");
            aobj.AlbumName = tb.Text;

            tb = (TextBox)gdvalbums.Rows[e.RowIndex].FindControl("txtcategory");
            aobj.Category = tb.Text;

            tb = (TextBox)gdvalbums.Rows[e.RowIndex].FindControl("txtnoofsongs");
            aobj.No_Of_Songs = Convert.ToInt32(tb.Text);

            tb = (TextBox)gdvalbums.Rows[e.RowIndex].FindControl("txtreleasedate");
            aobj.ReleaseDate = Convert.ToDateTime(tb.Text);

            tb = (TextBox)gdvalbums.Rows[e.RowIndex].FindControl("txtcompany");
            aobj.Company = tb.Text;

            tb = (TextBox)gdvalbums.Rows[e.RowIndex].FindControl("txtprice");
            aobj.Price = Convert.ToDecimal(tb.Text);

            tb = (TextBox)gdvalbums.Rows[e.RowIndex].FindControl("txtlanguage");
            aobj.Language = tb.Text;

            if (!abobj.UpdateAlbum(aobj))
            {
                lblmsg.Text = "Error";
            }

            gdvalbums.EditIndex = -1;
            PopulateAlbum();
        }

        protected void gdvalbums_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label lb = (Label)gdvalbums.Rows[e.RowIndex].FindControl("lblalbumid");
            int id = Convert.ToInt32(lb.Text);
            abobj.DeleteAlbumById(id);

            gdvalbums.EditIndex = -1;
            PopulateAlbum();
        }

        protected void gdvsongs_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            gdvsongs.PageIndex = e.NewPageIndex;
            PopulateSongs();
        }

        protected void gdvsongs_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            gdvsongs.EditIndex = -1;
            PopulateSongs();
        }

        protected void gdvsongs_RowEditing(object sender, GridViewEditEventArgs e)
        {
            gdvsongs.EditIndex = e.NewEditIndex;
            PopulateSongs();
        }

        protected void gdvsongs_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Songs sobj = new Songs();
            TextBox tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtsongid");
            sobj.SongsID = Convert.ToInt32(tb.Text);

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtsongname");
            sobj.SongName = tb.Text;

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtsinger");
            sobj.Singer = tb.Text;

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtmovie");
            sobj.Movie = tb.Text;

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtcomposedby");
            sobj.ComposedBy = tb.Text;

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtlanguage");
            sobj.Language = tb.Text;

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtlyrics");
            sobj.Lyrics = tb.Text;

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtyear");
            sobj.Year = Convert.ToInt32(tb.Text);

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtalbumid");
            sobj.AlbumID = Convert.ToInt32(tb.Text);

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtactor");
            sobj.Actor = tb.Text;

            tb = (TextBox)gdvsongs.Rows[e.RowIndex].FindControl("txtactress");
            sobj.Actress = tb.Text;

            if (!sbobj.UpdateSong(sobj))
            {
                lblmsg.Text = "Error";
            }

            gdvsongs.EditIndex = -1;
            PopulateSongs();
        }

        protected void gdvsongs_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            Label lb = (Label)gdvsongs.Rows[e.RowIndex].FindControl("lblsongid");
            int id = Convert.ToInt32(lb.Text);
            sbobj.RemoveSongBySongId(id);

            gdvsongs.EditIndex = -1;
            PopulateSongs();
        }

        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("HomePage.aspx");
        }

    }
}