﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class UserMaster : System.Web.UI.MasterPage
    {
        SongsBL sbobj = new SongsBL();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Necessary();
            }
        }
        protected void Necessary()
        {
            Button btn = (Button)this.Master.FindControl("btnlogin");
            btn.Text = "Welcome: ";
            btn.Enabled = false;
            btn = (Button)this.Master.FindControl("btnregister");
            btn.Text = Session["userId"].ToString();
            btn.Enabled = false;
        }
        
        protected void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                gdvusersongs.Enabled = true;
                switch (ddlby.SelectedIndex)
                {
                    case 0:
                        gdvusersongs.DataSource = sbobj.ShowAllSongs();
                        break;

                    case 1:
                        gdvusersongs.DataSource = sbobj.SearchSongBySinger(txtsearch.Text);
                        break;

                    case 2:
                        gdvusersongs.DataSource = sbobj.SearchSongByMovie(txtsearch.Text);
                        break;

                    case 3:
                        gdvusersongs.DataSource = sbobj.SearchSongByComposer(txtsearch.Text);
                        break;

                    case 4:
                        gdvusersongs.DataSource = sbobj.SearchSongByActor(txtsearch.Text);
                        break;

                    case 5:
                        gdvusersongs.DataSource = sbobj.SearchSongByActress(txtsearch.Text);
                        break;

                    case 6:
                        gdvusersongs.DataSource = sbobj.SearchSongByYear(Convert.ToInt32(txtsearch.Text));
                        break;

                    case 7:
                        gdvusersongs.DataSource = sbobj.SearchSongByLanguage(txtsearch.Text);
                        break;
                }
                gdvusersongs.DataBind();
            }
            catch (Exception)
            {
                Response.Redirect("Errorpage.aspx");
            }
        }

        protected void btnlogout_Click(object sender, EventArgs e)
        {
            Session.Abandon();
            Response.Redirect("HomePage.aspx");
        }

        protected void lnkdownload(object sender, EventArgs e)
        {
            int id = int.Parse((sender as LinkButton).CommandArgument);

            byte[] song = sbobj.DownloadSong(id);
            Response.Clear();
            Response.Buffer = true;
            Response.Charset = "";
            Response.Cache.SetCacheability(HttpCacheability.NoCache);
            Response.ContentType = "audio/mp3";
            Response.AppendHeader("Content-Disposition", "attachment; filename=" + "song"+id);
            Response.BinaryWrite(song);
            Response.Flush();
            Response.End();
        }
    }
}