﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class Register : System.Web.UI.Page
    {
        //Class Level Object Of Customer Layer
        CustomerBL cbobj = new CustomerBL();
        //Class Level Object Of Employee Layer
        EmployeeBL ebobj = new EmployeeBL();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            try
            {
                if (rdblistuser.SelectedIndex == 0)
                {
                    Customer cobj = new Customer();
                    cobj.Address = txtaddress.Text;
                    cobj.City = txtcity.Text;
                    cobj.CustName = txtname.Text;
                    cobj.CustomerID = Convert.ToInt32(txtid.Text);
                    cobj.DOB = Convert.ToDateTime(txtdateofbirth.Text);
                    cobj.MobileNo = txtmobileno.Text;
                    cobj.Password = txtpassword.Text;

                    if (cbobj.AddCustomer(cobj))
                    {
                        lblmsg.ForeColor = System.Drawing.Color.Green;
                        lblmsg.Text = "Customer Registered Successfully";
                    }
                    else
                    {
                        lblmsg.ForeColor = System.Drawing.Color.Red;
                        lblmsg.Text = "Unable to Register Customer";
                    }
                }
                else if (rdblistuser.SelectedIndex == 1)
                {
                    Employee eobj = new Employee();
                    eobj.Address = txtaddress.Text;
                    eobj.City = txtcity.Text;
                    eobj.DOB = Convert.ToDateTime(txtdateofbirth.Text);
                    eobj.EmployeeID = Convert.ToInt32(txtid.Text);
                    eobj.EmpName = txtname.Text;
                    eobj.MobileNo = txtmobileno.Text;
                    eobj.Password = txtpassword.Text;

                    if (ebobj.RegisterEmployee(eobj))
                    {
                        lblmsg.ForeColor = System.Drawing.Color.Green;
                        lblmsg.Text = "Employee Registered Successfully";
                    }
                    else
                    {
                        lblmsg.ForeColor = System.Drawing.Color.Red;
                        lblmsg.Text = "Unable to Register Employee";
                    }
                }
                else
                {
                    lblmsg.ForeColor = System.Drawing.Color.Red;
                    lblmsg.Text = "Please choose user type";
                }
            }
            catch (CustomerException cexp)
            {
                lblmsg.Text = cexp.Message.ToString();
            }
            catch (EmployeeExceptions eexp)
            {
                lblmsg.Text = eexp.Message.ToString();
            }
            catch (Exception exp)
            {
                lblmsg.Text = exp.Message.ToString();
            }
        }

        protected void rdblistuser_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (rdblistuser.SelectedIndex == 0)
            {
                txtid.Text = cbobj.AutoGenCustomerId().ToString();
            }
            else if (rdblistuser.SelectedIndex == 1)
            {
                txtid.Text = ebobj.AutoGenEmployeeId().ToString();
            }
            else
            {
                lblmsg.ForeColor = System.Drawing.Color.Red;
                lblmsg.Text = "Please choose user type";
            }
        }
    }
}