﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using System.IO;
using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;

namespace MJS.ASP
{
    public partial class AddMusic : System.Web.UI.Page
    {
        //Class Level Object of Bl LAyer
        SongsBL sbobj = new SongsBL();
        AlbumBL abobj = new AlbumBL();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                txtsongid.Text = sbobj.AutoGenSongId().ToString();
                ddlalbums.DataSource = abobj.ShowAllAlbum();
                ddlalbums.DataTextField = "AlbumName";
                ddlalbums.DataValueField = "AlbumId";
                ddlalbums.DataBind();
            }
        }

        protected void btnupload_Click(object sender, EventArgs e)
        {
            try
            {
                Songs sobj = new Songs();
                sobj.Actor = txtactor.Text;
                sobj.Actress = txtactress.Text;
                sobj.AlbumID = Convert.ToInt32(ddlalbums.SelectedValue);
                sobj.ComposedBy = txtcomposedby.Text;
                sobj.Language = txtlanguage.Text;
                sobj.Lyrics = txtlyrics.Text;
                sobj.Movie = txtmovie.Text;
                sobj.Singer = txtsinger.Text;
                sobj.SongName = txtsongname.Text;
                sobj.SongsID = Convert.ToInt32(txtsongid.Text);
                //Adding songs code
                Stream str = FileUploadSongs.PostedFile.InputStream;
                BinaryReader br = new BinaryReader(str);
                sobj.SPath = br.ReadBytes((Int32)str.Length);

                sobj.Year = Convert.ToInt32(txtyear.Text);

                if (sbobj.UploadSong(sobj))
                {
                    lblerrormsg.ForeColor = System.Drawing.Color.Green;
                    lblerrormsg.Text = "Song Uploaded ";
                }
                else
                {
                    lblerrormsg.ForeColor = System.Drawing.Color.Red;
                    lblerrormsg.Text = "Unable to Upload Song";
                }
                
            }
            catch (SongsExceptions sexp)
            {
                lblerrormsg.Text = sexp.Message.ToString();
            }
            catch (SqlException se)
            {
                lblerrormsg.Text = se.Message.ToString();
            }
            catch (Exception ex)
            {
                lblerrormsg.Text = ex.Message.ToString(); 
            }
        }

    }
}