﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Configuration;//For App.config File cstring
using System.Data;
using MJS.Entity;

namespace MJS.DAL
{
    public class MusicOrderDetailsDAL
    {
        public List<MusicOrderDetails> ShowAll()
        {
            try
            {
                //Creating a List of Type Entity for storing data from databse
                List<MusicOrderDetails> mList = new List<MusicOrderDetails>();
                //Making Connection using App.Config ConnectionString Attribute
                SqlConnection conObj = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
                //Creating an object of DataAdapter Class For storing The whole Table in DataTable
                SqlDataAdapter adap = new SqlDataAdapter("SELECT * FROM NNADLB.GuestContacts", conObj);
                //Making an Obejct of SqlCommandBuilder
                SqlCommandBuilder builder = new SqlCommandBuilder();
                //Making an object of DataTable for holding the whole Table
                DataTable dTable = new DataTable();
                //Filling Data into DataTable Object
                adap.Fill(dTable);

                //      Each row        in Table
                foreach (DataRow row in dTable.Rows)
                {
                    MusicOrderDetails obj = new MusicOrderDetails();
                    obj.MusicOrderID = Convert.ToInt32(row[0]);
                    obj.AlbumID = Convert.ToInt32(row[1]);
                    obj.UnitPrice = Convert.ToDecimal(row[2]);
                    obj.Qty = Convert.ToInt32(row[3]);
                    obj.Discount = Convert.ToInt32(row[4]);
                    obj.PaymentID = Convert.ToInt32(row[5]);
                    obj.TotAmount = Convert.ToDecimal(row[6]);

                   mList.Add(obj);
                }
                return mList;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (Exception w)
            {
                throw w;
            }
        }
    }
}
