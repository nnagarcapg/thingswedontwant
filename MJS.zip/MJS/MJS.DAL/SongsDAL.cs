﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;//FOr FIle

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;
using MJS.Exceptions;

namespace MJS.DAL
{
    public class SongsDAL
    {
        
        //Class Level Connection Object
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
        //Class Level Command Object
        SqlCommand cmd = new SqlCommand();

        public bool RemoveSongBySongId(int songId)
        {
            bool removesong = false;;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_deleteSongById";
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@i", songId);

                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();

                if (result > 0)
                    removesong = true;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return removesong;
        }
        
        //Updating a song
        public bool UpdateSong(Songs s)
        {
            bool uploadSong = false;
            try
            {

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_updateasong";
                cmd.Connection = con;


                cmd.Parameters.Add(new SqlParameter("@i", s.SongsID));
                cmd.Parameters.Add(new SqlParameter("@n", s.SongName));
                cmd.Parameters.Add(new SqlParameter("@s", s.Singer));
                cmd.Parameters.Add(new SqlParameter("@m", s.Movie));
                cmd.Parameters.Add(new SqlParameter("@c", s.ComposedBy));
                cmd.Parameters.Add(new SqlParameter("@a", s.Actor));
                cmd.Parameters.Add(new SqlParameter("@ac", s.Actress));
                cmd.Parameters.Add(new SqlParameter("@l", s.Lyrics));
                cmd.Parameters.Add(new SqlParameter("@y", s.Year));
                cmd.Parameters.Add(new SqlParameter("@ai", s.AlbumID));
                cmd.Parameters.Add(new SqlParameter("@lang", s.Language));


                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                {
                    uploadSong = true;
                }
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return uploadSong;
        }

        //Upload Song 
        public bool UploadSong(Songs s)
        {
            bool flag;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_addSongswsp";
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@i", s.SongsID);
                cmd.Parameters.AddWithValue("@n", s.SongName);
                cmd.Parameters.AddWithValue("@s", s.Singer);
                cmd.Parameters.AddWithValue("@m", s.Movie);
                cmd.Parameters.AddWithValue("@c", s.ComposedBy);
                cmd.Parameters.AddWithValue("@a", s.Actor);
                cmd.Parameters.AddWithValue("@ac", s.Actress);
                cmd.Parameters.AddWithValue("@l", s.Lyrics);
                cmd.Parameters.AddWithValue("@y", s.Year);
                cmd.Parameters.AddWithValue("@ai", s.AlbumID);
                cmd.Parameters.AddWithValue("@lang", s.Language);
                cmd.Parameters.AddWithValue("@spath", s.SPath);
                //if (File.Exists(s.SPath))
                //{
                //    FileStream file = new FileStream(s.SPath, FileMode.Open);
                //    cmd.Parameters.AddWithValue("@spath", file);
                //}
                //else
                //{
                //    string m = "File does not Exits";
                //    throw new SongsExceptions(m);
                //}
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                {
                    flag = true;
                }
                else
                {
                    flag = false;
                }
                return flag;
            }
            catch (Exception)
            {
                throw;
            }

        }

        public int AutoGenSongId()
        {
            int id = 0;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_songautoid";
                cmd.Connection = con;

                con.Open();
                id = (int)cmd.ExecuteScalar();
                con.Close();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return id;
        }

        //to Be modified To Download From DataBase To particuler Path
        public byte[] DownloadSong(int id)
        {
            byte[] c;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_songdwnld";
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@id",id);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                dr.Read();
                c = (byte[])dr[0];
                con.Close();

                //if (dr.HasRows)
                //{
                //    File.WriteAllBytes("P:\\songs\\song"+c+".mp3", dr[0] as byte[]);
                //    con.Close();
                //}
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return c;
        }

        //Showing All Songs
        public List<Songs> ShowAllSongs()
        {
            List<Songs> allsongs = new List<Songs>();
            try
            {
                SqlDataAdapter adap = new SqlDataAdapter("MJS.udp_showallsongs", con);

                DataTable dt = new DataTable();
                adap.Fill(dt);

                foreach (DataRow row in dt.Rows)
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = Convert.ToInt32(row[0]);
                    sobj.SongName = row[1].ToString();
                    sobj.Singer = row[2].ToString();
                    sobj.Movie = row[3].ToString();
                    sobj.ComposedBy = row[4].ToString();
                    sobj.Actor = row[5].ToString();
                    sobj.Actress = row[6].ToString();
                    sobj.Lyrics = row[7].ToString();
                    sobj.Year = Convert.ToInt32(row[8]);
                    sobj.AlbumID = Convert.ToInt32(row[9]);
                    sobj.Language = row[10].ToString();

                    allsongs.Add(sobj);
                }
            }
            catch (Exception)
            {
                throw;
            }
            return allsongs;
        }

        //Search Song By Singer
        public List<Songs> SearchSongBySinger(string singerName)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object

            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchSongBySinger";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@name", singerName);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return getsongList;
        }

        //Search Song By Genre
        public List<Songs> SearchSongByLanguage(string langname)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchSongByLang";
                cmd.Connection = con;
                
                cmd.Parameters.Add(new SqlParameter("@name", langname));
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                con.Close();
                
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return getsongList;
        }

        // Search Song By Year
        public List<Songs> SearchSongByYear(int year)
        {
            List<Songs> getsongList = new List<Songs>();
            //Creating connection Object
            
            try
            {
                //SqlCommand cmd = new SqlCommand("select * from MJS.Songs where RYear=@year", connobj);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchSongByYear";
                cmd.Connection = con;
                
                cmd.Parameters.AddWithValue("@year", year);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                con.Close();
                
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return getsongList;
        }

        //Searcg song by Actor Name
        public List<Songs> SearchSongByActor(string actorName)
        {
            List<Songs> getsongList = new List<Songs>();
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchSongByActor";
                cmd.Connection = con;
                
                cmd.Parameters.Add(new SqlParameter("@name", actorName));
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return getsongList;
        }

        //Search songs by Actress name
        public List<Songs> SearchSongByActress(string actressName)
        {
            List<Songs> getsongList = new List<Songs>();
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchSongByActress";
                cmd.Connection = con;
                
                cmd.Parameters.AddWithValue("@name", actressName);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw ;
            }
            return getsongList;
        }

        // Search Song By Movie
        public List<Songs> SearchSongByMovie(string movieName)
        {
            List<Songs> getsongList = new List<Songs>();
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchSongByMovie";
                cmd.Connection = con;
                
                cmd.Parameters.Add(new SqlParameter("@movie", movieName));
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {
                    Songs sobj = new Songs();
                    sobj.SongsID = sdr.GetInt32(0);
                    sobj.SongName = sdr.GetString(1);
                    sobj.Singer = sdr.GetString(2);
                    sobj.Movie = sdr.GetString(3);
                    sobj.ComposedBy = sdr.GetString(4);
                    sobj.Actor = sdr.GetString(5);
                    sobj.Actress = sdr.GetString(6);
                    sobj.Lyrics = sdr.GetString(7);
                    sobj.Year = sdr.GetInt32(8);
                    sobj.AlbumID = sdr.GetInt32(9);
                    sobj.Language = sdr.GetString(10);

                    getsongList.Add(sobj);
                }
                con.Close();
            }
            catch (SqlException )
            {
                con.Close();
                throw ;
            }
            catch (Exception)
            {
                con.Close();
                throw ;
            }
            return getsongList;
        }
        
        //Search Song By Composer
        public List<Songs> SearchSongByComposer(string name)
        {
            try
            {
                List<Songs> getsongList = new List<Songs>();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchSongByComposer";
                cmd.Connection = con;

                cmd.Parameters.Add(new SqlParameter("@name", name));
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                if (sdr.HasRows)
                {
                    sdr.Read();
                    foreach (var item in getsongList)
                    {
                        Songs sobj = new Songs();
                        sobj.SongsID = Convert.ToInt16(sdr[0]);
                        sobj.SongName = sdr[1].ToString();
                        sobj.Singer = sdr[2].ToString();
                        sobj.Movie = sdr[3].ToString();
                        sobj.ComposedBy = sdr[4].ToString();
                        sobj.Actor = sdr[5].ToString();
                        sobj.Actress = sdr[6].ToString();
                        sobj.Lyrics = sdr[7].ToString();
                        sobj.Year = sdr.GetInt32(8);
                        sobj.AlbumID = Convert.ToInt16(sdr[9]);
                        sobj.Language = sdr[10].ToString();
                        getsongList.Add(sobj);

                    }
                }
                con.Close();
                return getsongList;
            }
            catch (Exception )
            {
                throw ;
            }
        }

    }
}
