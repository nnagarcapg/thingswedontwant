﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;

namespace MJS.DAL
{
    public class CustomerDAL
    {
        public bool LoginCredentials(Customer rec)//OK -
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM MJS.Customer where CustomerID=@eid and Pass=@password", con);

                cmd.Parameters.AddWithValue("@eid", rec.CustomerID);
                cmd.Parameters.AddWithValue("@password", rec.Password);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                bool flag = dr.HasRows;
                con.Close();

                if (flag)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (SqlException e)
            {
                con.Close();
                throw e;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
        }

        public bool AddCustomer(Customer c)
        {
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "mk_AddCustomer";
                cmd.Connection = con;

                cmd.Parameters.AddWithValue("@i", c.CustomerID);
                cmd.Parameters.AddWithValue("@n", c.CustName);
                cmd.Parameters.AddWithValue("@a", c.Address);
                cmd.Parameters.AddWithValue("@d", c.DOB);
                cmd.Parameters.AddWithValue("@c", c.City);
                cmd.Parameters.AddWithValue("@p", c.Password);
                cmd.Parameters.AddWithValue("@m", c.MobileNo);

                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                {
                    return true;
                }
                else
                    return false;
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
        }

        public Customer SearchCustomerById(int id)
        {
            Customer c = new Customer();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "mk_SearchCustomerById";
                cmd.Parameters.Add(new SqlParameter("@i", id));
                cmd.Connection = con;

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    c.CustomerID = Convert.ToInt32(dr[0]);
                    c.CustName = dr[1].ToString();
                    c.Address = dr[2].ToString();
                    c.DOB = Convert.ToDateTime(dr[3]);
                    c.City = dr[4].ToString();
                    c.Password = dr[5].ToString();
                    c.MobileNo = dr[6].ToString();
                }
                con.Close();
            }
            catch (SqlException e)
            {
                con.Close();
                throw e;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
            return c;
        }

        public bool RemoveCustomer(int id)
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "mk_RemoveCustomer";
                cmd.Connection = con;

                cmd.Parameters.Add(new SqlParameter("@i", id));
                con.Open();
                int r = cmd.ExecuteNonQuery();
                con.Close();
                if (r > 0)
                    flag = true;
            }
            catch (SqlException e)
            {
                con.Close();
                throw e;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
            return flag;
        }

        public bool UpdateCustomer(Customer c)
        {
            bool flag = false;

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);

            SqlCommand cmd = new SqlCommand();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "mk_UpdateCustomer";
            cmd.Connection = con;


            cmd.Parameters.Add(new SqlParameter("@i", Convert.ToString(c.CustomerID)));
            cmd.Parameters.Add(new SqlParameter("@n", Convert.ToString(c.CustName)));
            cmd.Parameters.Add(new SqlParameter("@a", Convert.ToString(c.Address)));
            cmd.Parameters.Add(new SqlParameter("@d", Convert.ToString(c.DOB)));
            cmd.Parameters.Add(new SqlParameter("@c", Convert.ToString(c.City)));
            cmd.Parameters.Add(new SqlParameter("@p", Convert.ToString(c.Password)));
            cmd.Parameters.Add(new SqlParameter("@m", Convert.ToString(c.MobileNo)));

            con.Open();
            int r = cmd.ExecuteNonQuery();
            con.Close();
            if (r > 0)
                flag = true;
            return flag;
        }

        public List<Customer> DisplayCustomer()
        {
            List<Customer> custList = new List<Customer>();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);

            SqlDataAdapter adap = new SqlDataAdapter("SELECT * FROM MJS.Customer", con);
            //Making an Obejct of SqlCommandBuilder
            SqlCommandBuilder builder = new SqlCommandBuilder();
            //Making an object of DataTable for holding the whole Table
            DataTable dTable = new DataTable();
            //Filling Data into DataTable Object
            adap.Fill(dTable);

            foreach (DataRow row in dTable.Rows)
            {
                Customer obj = new Customer();
                obj.CustomerID = Convert.ToInt32(row[0]);
                obj.CustName = Convert.ToString(row[1]);
                obj.Address = Convert.ToString(row[2]);
                obj.DOB = Convert.ToDateTime(row[3]);
                obj.City = Convert.ToString(row[4]);
                obj.Password = Convert.ToString(row[5]);
                obj.MobileNo = Convert.ToString(row[6]);

                custList.Add(obj);
            }
            return custList;
        }
    }
}
