﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;

namespace MJS.DAL
{
    public class MusicOrderDAL
    {
        public List<MusicOrder> SearchMusicOrder(int OrderId)
        {
            //Making an Obejct of SqlCommandBuilder
            List<MusicOrder> getList = new List<MusicOrder>();
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            SqlCommandBuilder builder = new SqlCommandBuilder();
            //Making an object of DataTable for holding the whole Table
            DataTable dTable = new DataTable();
            //Filling Data into DataTable Object
            SqlDataAdapter adap = new SqlDataAdapter("SELECT * FROM MJS.MusicOrder", con);
            adap.Fill(dTable);

            foreach (DataRow row in dTable.Rows)
            {
                MusicOrder obj = new MusicOrder();
                obj.OrderID = Convert.ToInt32(row[0]);
                obj.OrderDate = Convert.ToDateTime(row[1]);
                obj.DeliveryDate = Convert.ToDateTime(row[2]);
                obj.OrdPaymentID = Convert.ToInt32(row[3]);
                obj.EmployeeID = Convert.ToInt32(row[4]);
                obj.CustomerID = Convert.ToInt32(row[5]);

                getList.Add(obj);
            }

            return getList;
        }

        public bool AddOrder(MusicOrder Mo)
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);

            SqlCommand cmd = new SqlCommand("INSERT INTO MJS.MusicOrder VALUES(@od, @dd, @opi, @ei, @ci)", con);

            cmd.Parameters.AddWithValue("@od", Mo.OrderDate);
            cmd.Parameters.AddWithValue("@dd", Mo.DeliveryDate);
            cmd.Parameters.AddWithValue("@opi", Mo.OrdPaymentID);
            cmd.Parameters.AddWithValue("@ei", Mo.EmployeeID);
            cmd.Parameters.AddWithValue("@ci", Mo.CustomerID);

            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();

            if (res > 0)
            {
                flag= true;
            }
            return flag;
        }

        public bool DeleteOrder(int OrderId)
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            SqlCommand cmd = new SqlCommand("DELETE FROM MJS.MusicOrder WHERE ORDERID=@oi", con);

            cmd.Parameters.AddWithValue("@oi", OrderId);

            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();

            if (res > 0)
            {
                flag = true;
            }

            return flag;
        }

        public bool UpdateOrder(MusicOrder Mo)
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);

            SqlCommand cmd = new SqlCommand("UPDATE MJS.MusicOrder SET OrderID=@oi, OrderDate=@od, DeliveryDate=@dd, OrdPaymentID=@opi, EmployeeID=@ei, CustomerID=@ci", con);

            cmd.Parameters.AddWithValue("@oi", Mo.OrderID);
            cmd.Parameters.AddWithValue("@od", Mo.OrderDate);
            cmd.Parameters.AddWithValue("@dd", Mo.DeliveryDate);
            cmd.Parameters.AddWithValue("@opi", Mo.OrdPaymentID);
            cmd.Parameters.AddWithValue("@ei", Mo.EmployeeID);
            cmd.Parameters.AddWithValue("@ci", Mo.CustomerID);

            con.Open();
            int res = cmd.ExecuteNonQuery();
            con.Close();

            if (res > 0)
            {
                flag = true;
            }

            return flag;
        }
    }
}
