﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;

namespace MJS.DAL
{
    public class EmployeeDAL
    {
        //Class Level Connection Object
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
        //Class Level Command Object
        SqlCommand cmd = new SqlCommand();

        public bool RegisterEmployee(Employee newP)
        {
            bool flag = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_addEmp";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@id", newP.EmployeeID);
                cmd.Parameters.AddWithValue("@n", newP.EmpName);
                cmd.Parameters.AddWithValue("@a", newP.Address);
                cmd.Parameters.AddWithValue("@dob", newP.DOB);
                cmd.Parameters.AddWithValue("@c", newP.City);
                cmd.Parameters.AddWithValue("@p", newP.Password);
                cmd.Parameters.AddWithValue("@mn", newP.MobileNo);

                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                        flag = true;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return flag;
        }

        public bool LoginCredentials(Employee rec)
        {
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_loginEmployee";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@eid", rec.EmployeeID);
                cmd.Parameters.AddWithValue("@password", rec.Password);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                bool flag = dr.HasRows;
                con.Close();
                if (flag)
                    return true;
                else
                    return false;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
        }

        public bool UpdateEmployee(Employee emp)
        {
            bool empupdate = false;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_updateEmployee";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@eid", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@ename", emp.EmpName);
                cmd.Parameters.AddWithValue("@address", emp.Address);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@city", emp.City);
                cmd.Parameters.AddWithValue("@password", emp.Password);
                cmd.Parameters.AddWithValue("@mobileno", emp.MobileNo);
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    empupdate = true;
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return empupdate;
        }

        public Employee SearchEmployeeById(int id)
        {
            Employee c = new Employee();
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_searchbyid";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@id", id);
                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    c.EmployeeID = Convert.ToInt32(dr[0]);
                    c.EmpName = dr[1].ToString();
                    c.Address = dr[2].ToString();
                    c.DOB = Convert.ToDateTime(dr[3]);
                    c.City = dr[4].ToString();
                    c.Password = dr[5].ToString();
                    c.MobileNo = dr[6].ToString();
                }
                dr.Close();
                con.Close();
            }
            catch (SqlException)
            {
                con.Close();
                throw;
            }
            catch (Exception)
            {
                con.Close();
                throw;
            }
            return c;
        }

        public int AutoGenEmployeeId()
        {
            int id = 0;
            try
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_employeeautoid";
                cmd.Connection = con;

                con.Open();
                id = (int)cmd.ExecuteScalar();
                con.Close();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
            return id;
        }
    }

}
