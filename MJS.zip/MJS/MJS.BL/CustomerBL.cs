﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using MJS.Entity;
using MJS.DAL;

namespace MJS.BL
{
    public class CustomerBL
    {
        public bool LoginCredentials(Customer rec)
        {
            try
            {
                CustomerDAL obj = new CustomerDAL();
                return obj.LoginCredentials(rec);
            }
            catch (SqlException e)
            {
                throw e;
            }
            catch (Exception w)
            {
                throw w;
            }
        }
    }
}
