﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Text.RegularExpressions;
using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.DAL;

namespace MJS.BL
{
    public class CustomerBL
    {
        //Class Level Object of Customer DAL
        CustomerDAL dobj = new CustomerDAL();

        public bool LoginCredentials(Customer rec)
        {
            bool flag = false;
            try
            {
                flag = dobj.LoginCredentials(rec);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return flag;
        }

        public bool AddCustomer(Customer newP)
        {
            bool flag = false;
            try
            {
                if (ValidateEmployee(newP))
                {
                    flag = dobj.AddCustomer(newP);
                }
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return flag;
        }

        public int AutoGenCustomerId()
        {
            try
            {
                return dobj.AutoGenCustomerId();
            }
            catch (SqlException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Customer SearchCustomerById(int id)
        {
            try
            {
                return dobj.SearchCustomerById(id);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
        }

        public bool RemoveCustomer(int id)
        {
            bool flag = false;
            try
            {
                flag = dobj.RemoveCustomer(id);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }

            return flag;
        }

        public bool UpdateCustomer(Customer c)
        {
            bool flag = false;
            try
            {
                flag = dobj.UpdateCustomer(c);
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return flag;
        }

        public List<Customer> DisplayCustomer()
        {
            List<Customer> retList = null;
            try
            {
                retList = dobj.DisplayCustomer();
            }
            catch (SqlException )
            {
                throw ;
            }
            catch (Exception )
            {
                throw ;
            }
            return retList;
        }

        private bool ValidateEmployee(Customer n)
        {
            bool flag = true;
            StringBuilder sb = new StringBuilder();
            if (n.CustomerID <1000)
            {
                flag = false;
                sb.Append("\nPlease: ID must be greater then 1000");
            }

            if (n.CustName == string.Empty)
            {
                flag = false;
                sb.Append("\nPlease: Name cant be empty");
            }

            if (n.CustName == " ")
            {
                flag = false;
                sb.Append("\nPlease: Name cant be empty");
            }

            Regex r = new Regex("[a-zA-Z]*$");//A Regular Expression Namsespace's Class which helps to check string 
            if (!(r.IsMatch(n.CustName)))
            {
                flag = false;
                sb.Append("\nPlease: Only Characters - Name");
            }

            if (n.City == string.Empty)
            {
                flag = false;
                sb.Append("\nPlease: City cant be empty");
            }

            if (n.City == " ")
            {
                flag = false;
                sb.Append("\nPlease: City cant be empty");
            }

            if (!(r.IsMatch(n.City)))
            {
                flag = false;
                sb.Append("\nPlease: Only Characters - City");
            }
            /*
                DateTime.Compare(date1, date2);
             * It always return integer of 3 type
             * -1 - date1 is earlier then date 2
             *  0 - date1 is equals to date 2
             *  1 - date1 is later then date 2
             *  
             * Less than zero ---- t1 is earlier than t2.
             * Zero ---- t1 is the same as t2.
             * Greater than zero ---- t1 is later than t2.
             */
            if (n.DOB >= DateTime.Now)
            {
                flag = false;
                sb.Append("\nPlease: Date of birth is Invalid");
            }

            if (n.MobileNo.Length < 10 || n.MobileNo.Length > 10)
            {
                flag = false;
                sb.Append("\nPlease: Mobile no should be of 10 digit");
            }

            if (n.Password.Length < 6)
            {
                flag = false;
                sb.Append("\nPlease: Password should be greater then 6 characters");
            }

            Regex rp = new Regex("[a-zA-Z0-9]*$");
            if (!(rp.IsMatch(n.Password)))
            {
                flag = false;
                sb.Append("\nPlease: Password format number and character");
            }

            if (flag == false)
            {
                throw new CustomerException(sb.ToString());
            }

            return flag;
        }

    }
}
