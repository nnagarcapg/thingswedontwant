﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJS.Entity
{
    public class Songs
    {
        //SongID, SongName, Singer, Movie, ComposedBy, Lyrics, Year, AlbumID, Language

        #region Fields
        int songsID;
        string songName;
        string singer;
        string movie;
        string composedBy;
        string lyrics;
        int year;
        int albumID;
        string language;
        string actor;
        string actress;
        byte[] sPath;

        #endregion

        #region Properties
        public byte[] SPath
        {
            get { return sPath; }
            set { sPath = value; }
        }
        public string Actress
        {
            get { return actress; }
            set { actress = value; }
        }

        public string Actor
        {
            get { return actor; }
            set { actor = value; }
        }

        public string Language
        {
            get { return language; }
            set { language = value; }
        }

        public int AlbumID
        {
            get { return albumID; }
            set { albumID = value; }
        }

        public int Year
        {
            get { return year; }
            set { year = value; }
        }

        public string Lyrics
        {
            get { return lyrics; }
            set { lyrics = value; }
        }

        public string ComposedBy
        {
            get { return composedBy; }
            set { composedBy = value; }
        }

        public string Movie
        {
            get { return movie; }
            set { movie = value; }
        }

        public string Singer
        {
            get { return singer; }
            set { singer = value; }
        }

        public string SongName
        {
            get { return songName; }
            set { songName = value; }
        }

        public int SongsID
        {
            get { return songsID; }
            set { songsID = value; }
        }
        #endregion
    }
}
