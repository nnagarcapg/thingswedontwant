﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJS.Entity
{
    public class Songs
    {
        //SongID, SongName, Singer, Movie, ComposedBy, Lyrics, Year, AlbumID, Language

        #region Fields
        int songsID;
        string songName;
        string singer;
        string movie;
        string composedBy;
        string lyrics;
        string year;
        int albumID;
        string language;
        #endregion

        #region Properties
        public string Language
        {
            get { return language; }
            set { language = value; }
        }

        public int AlbumID
        {
            get { return albumID; }
            set { albumID = value; }
        }

        public string Year
        {
            get { return year; }
            set { year = value; }
        }

        public string Lyrics
        {
            get { return lyrics; }
            set { lyrics = value; }
        }

        public string ComposedBy
        {
            get { return composedBy; }
            set { composedBy = value; }
        }

        public string Movie
        {
            get { return movie; }
            set { movie = value; }
        }

        public string Singer
        {
            get { return singer; }
            set { singer = value; }
        }

        public string SongName
        {
            get { return songName; }
            set { songName = value; }
        }

        public int SongsID
        {
            get { return songsID; }
            set { songsID = value; }
        }
        #endregion
    }
}
