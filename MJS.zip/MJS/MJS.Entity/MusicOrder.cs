﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJS.Entity
{
    public class MusicOrder
    {
        //OrdederID, OrderDate, DeleveryDate, OrdPaymentID, EmployeeID, CustomerID 

        #region Fields
        int orderID;
        DateTime orderDate;
        DateTime deliveryDate;
        int ordPaymentID;
        int employeeID;
        int customerID;
        #endregion

        #region Properties
        public int CustomerID
        {
            get { return customerID; }
            set { customerID = value; }
        }

        public int EmployeeID
        {
            get { return employeeID; }
            set { employeeID = value; }
        }

        public int OrdPaymentID
        {
            get { return ordPaymentID; }
            set { ordPaymentID = value; }
        }

        public DateTime DeliveryDate
        {
            get { return deliveryDate; }
            set { deliveryDate = value; }
        }

        public DateTime OrderDate
        {
            get { return orderDate; }
            set { orderDate = value; }
        }

        public int OrderID
        {
            get { return orderID; }
            set { orderID = value; }
        }
        #endregion
    }
}
