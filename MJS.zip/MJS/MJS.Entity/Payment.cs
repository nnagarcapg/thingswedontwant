﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJS.Entity
{
    public class Payment
    {
        //PaymentID, PayAccName,  PayOrderID, PaymentDate, Amount     PaymentMethod

        #region Fields
        int paymentID;
        string payAccName;
        int payOrderID;
        DateTime paymentDate;
        decimal amount;
        string paymentMethod;
        #endregion

        #region Properties
        public string PaymentMethod
        {
            get { return paymentMethod; }
            set { paymentMethod = value; }
        }

        public decimal Amount
        {
            get { return amount; }
            set { amount = value; }
        }

        public DateTime PaymentDate
        {
            get { return paymentDate; }
            set { paymentDate = value; }
        }

        public int PayOrderID
        {
            get { return payOrderID; }
            set { payOrderID = value; }
        }

        public string PayAccName
        {
            get { return payAccName; }
            set { payAccName = value; }
        }

        public int PaymentID
        {
            get { return paymentID; }
            set { paymentID = value; }
        }
        #endregion
    }
}
