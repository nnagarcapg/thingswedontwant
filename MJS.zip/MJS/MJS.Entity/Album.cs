﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJS.Entity
{
    public class Album
    {
        //AlbumID, AlbumName, Category, No_Of_Songs, ReleaseDate, Company, Price, Language

        #region Fields
        int albumID;
        string albumName;
        string category;
        int no_Of_Songs;
        DateTime releaseDate;
        string company;
        decimal price;
        string language;
        #endregion

        #region Properties
        public string Language
        {
            get { return language; }
            set { language = value; }
        }

        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        public string Company
        {
            get { return company; }
            set { company = value; }
        }

        public DateTime ReleaseDate
        {
            get { return releaseDate; }
            set { releaseDate = value; }
        }

        public int No_Of_Songs
        {
            get { return no_Of_Songs; }
            set { no_Of_Songs = value; }
        }

        public string Category
        {
            get { return category; }
            set { category = value; }
        }

        public string AlbumName
        {
            get { return albumName; }
            set { albumName = value; }
        }

        public int AlbumID
        {
            get { return albumID; }
            set { albumID = value; }
        }
        #endregion
    }
}
