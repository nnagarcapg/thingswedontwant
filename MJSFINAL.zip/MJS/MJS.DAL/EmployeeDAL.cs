﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;//For ADO.NET
using System.Configuration;//For Connection string
using System.Data;//For DataTable
using MJS.Entity;

namespace MJS.DAL
{
    public class EmployeeDAL
    {
        public bool RegisterEmployee(Employee newP)
        {
            bool flag = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["cs"].ConnectionString);
            try
            {
                //SqlCommand cmd = new SqlCommand("INSERT INTO MJS.Employee VALUES(@id,@n, @a, @dob, @c, @p, @mn)", con);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_addEmp";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@id", newP.EmployeeID);
                cmd.Parameters.AddWithValue("@n", newP.EmpName);
                cmd.Parameters.AddWithValue("@a", newP.Address);
                cmd.Parameters.AddWithValue("@dob", newP.DOB);
                cmd.Parameters.AddWithValue("@c", newP.City);
                cmd.Parameters.AddWithValue("@p", newP.Password);
                cmd.Parameters.AddWithValue("@mn", newP.MobileNo);

                con.Open();
                int res = cmd.ExecuteNonQuery();
                con.Close();
                if (res > 0)
                        flag = true;
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
            return flag;
        }

        public bool LoginCredentials(Employee rec)
        {

            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                //SqlCommand cmd = new SqlCommand("SELECT * FROM MJS.Employee where EmployeeID=@eid and Pass=@password", con);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_loginEmployee";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@eid", rec.EmployeeID);
                cmd.Parameters.AddWithValue("@password", rec.Password);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                bool flag = dr.HasRows;
                con.Close();
                if (flag)
                    return true;
                else
                    return false;
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
        }

        public bool UpdateEmployee(Employee emp)
        {
            bool empupdate = false;
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                //SqlCommand cmd = new SqlCommand("UPDATE MJS.Employee set EmpName=@ename, Addess=@address, DOB=@dob, City=@city, Pass=@password, MobileNo=@mobileno where EmployeeID=@eid", con);
                SqlCommand cmd = new SqlCommand();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = "MJS.udp_updateEmployee";
                cmd.Connection = con;
                cmd.Parameters.AddWithValue("@eid", emp.EmployeeID);
                cmd.Parameters.AddWithValue("@ename", emp.EmpName);
                cmd.Parameters.AddWithValue("@address", emp.Address);
                cmd.Parameters.AddWithValue("@dob", emp.DOB);
                cmd.Parameters.AddWithValue("@city", emp.City);
                cmd.Parameters.AddWithValue("@password", emp.Password);
                cmd.Parameters.AddWithValue("@mobileno", emp.MobileNo);
                con.Open();
                int result = cmd.ExecuteNonQuery();
                con.Close();
                if (result > 0)
                    empupdate = true;
            }
            catch (SqlException v)
            {
                con.Close();
                throw v;
            }
            catch (Exception w)
            {
                con.Close();
                throw w;
            }
            return empupdate;
        }
    }

}
