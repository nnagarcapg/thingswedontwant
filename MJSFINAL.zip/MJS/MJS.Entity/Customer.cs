﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MJS.Entity
{
    public class Customer
    {
        //CustomerID, CustName, Address, DOB, City, Password MobileNo

        #region Fields
        int customerID;
        string custName;
        string address;
        DateTime dOB;
        string city;
        string password;
        string mobileNo;
        #endregion

        #region Property
        public string MobileNo
        {
            get { return mobileNo; }
            set { mobileNo = value; }
        }

        public string Password
        {
            get { return password; }
            set { password = value; }
        }

        public string City
        {
            get { return city; }
            set { city = value; }
        }

        public DateTime DOB
        {
            get { return dOB; }
            set { dOB = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public string CustName
        {
            get { return custName; }
            set { custName = value; }
        }

        public int CustomerID
        {
            get { return customerID; }
            set { customerID = value; }
        }
        #endregion
    }
}
