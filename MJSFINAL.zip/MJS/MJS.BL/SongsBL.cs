﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Text.RegularExpressions;
using System.Data.SqlClient;
using MJS.Exceptions;
using MJS.Entity;
using MJS.DAL;

namespace MJS.BL
{
    public class SongsBL
    {
        public int DownloadSong(int id)
        {
            try
            {
                SongsDAL obj = new SongsDAL();
                return obj.DownloadSong(id);
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }
        }

        public bool RemoveSongBySongId(int songId)//
        {
            bool flag = false;
            try
            {
                SongsDAL dobj = new SongsDAL();
                flag = dobj.RemoveSongBySongId(songId);
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }
            return flag;
        }

        public bool RemoveSongBySongName(string songName)
        {
            bool flag = false;
            try
            {

            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }
            return flag;
        }

        public bool UpdateSinger(int songId, string singerName)
        {
            bool flag = false;
            try
            {

            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }

            return flag;
        }

        public bool UpdateSong(Songs s)//
        {
            bool flag = false;
            try
            {
                SongsDAL obj = new SongsDAL();
                if (ValidateSong(s))
                {
                    flag = obj.UpdateSong(s);
                }
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }
            return flag;
        }

        public bool UploadSong(Songs s)//
        {
            bool flag = false;
            try
            {
                SongsDAL obj = new SongsDAL();
                if (ValidateSong(s))
                {
                    flag = obj.UploadSong(s);
                }
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }
            return flag;
        }

        public List<Songs> SearchSongByComposer(string name)//
        {
            List<Songs> rlist = null;
            try
            {

            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }
            return rlist;
        }

        public List<Songs> SearchSongBySinger(string singerName)//
        {
            List<Songs> rlist = null;
            try
            {
                SongsDAL dobj = new SongsDAL();
                rlist = dobj.SearchSongBySinger(singerName);
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }
            return rlist;
        }

        public List<Songs> SearchSongByLanguage(string langname)//
        {
            List<Songs> rlist = null;

            try
            {
                SongsDAL dobj = new SongsDAL();
                rlist = dobj.SearchSongByLanguage(langname);
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }

            return rlist;
        }

        public List<Songs> SearchSongByActor(string actorName)//
        {
            List<Songs> rlist = null;

            try
            {
                SongsDAL dobj = new SongsDAL();
                rlist = dobj.SearchSongByActor(actorName);
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }

            return rlist;
        }

        public List<Songs> SearchSongByActress(string actressName)//
        {
            List<Songs> rlist = null;

            try
            {
                SongsDAL dobj = new SongsDAL();
                rlist = dobj.SearchSongByActress(actressName);
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }

            return rlist;
        }

        public List<Songs> SearchSongByYear(int year)//
        {
            List<Songs> rlist = null;

            try
            {
                SongsDAL obj = new SongsDAL();
                rlist = obj.SearchSongByYear(year);
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }

            return rlist;
        }

        public List<Songs> SearchSongByMovie(string movieName)//
        {
            List<Songs> rlist = null;

            try
            {
                SongsDAL dobj = new SongsDAL();
                rlist = dobj.SearchSongByMovie(movieName);
            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }

            return rlist;
        }

        public List<Songs> SearchSongByGenre(string genre)
        {
            List<Songs> rlist = null;

            try
            {

            }
            catch (SqlException v)
            {
                throw v;
            }
            catch (Exception w)
            {
                throw w;
            }

            return rlist;
        }

        private bool ValidateSong(Songs s)
        {
            bool flag = true;
            StringBuilder sb = new StringBuilder();
            if (s.SongsID < 1000)
            {
                flag = false;
                sb.Append("\nID cant be Negative");
            }

            if (s.SongName == string.Empty)
            {
                flag = false;
                sb.Append("\nName cant be empty");
            }

            if (s.Singer == string.Empty)
            {
                flag = false;
                sb.Append("\nSinger Name can't Empty");
            }

            if (s.Movie == string.Empty)
            {
                flag = false;
                sb.Append("\nMovie cant be empty");
            }

            if (s.Lyrics == string.Empty)
            {
                flag = false;
                sb.Append("\nLyrics cant be empty");
            }

            if (s.Year <= 1800 )
            {
                flag = false;
                sb.Append("\nYear Should be greater than 1900");
            }

            if (s.Language == string.Empty)
            {
                flag = false;
                sb.Append("\nLanguage cant be empty");
            }

            if (s.ComposedBy == string.Empty)
            {
                flag = false;
                sb.Append("\nComposer cant be empty");
            }

            if (s.AlbumID < 1000)
            {
                flag = false;
                sb.Append("\n Album id cant be negative");
            }

            if (s.Actress == string.Empty)
            {
                flag = false;
                sb.Append("\n Actress cant be empty");
            }

            if (s.Actor == string.Empty)
            {
                flag = false;
                sb.Append("\nActor cant be empty");
            }

            if (flag == false)
            {
                throw new SongsExceptions(sb.ToString());
            }

            return flag;
        }
    }
}
