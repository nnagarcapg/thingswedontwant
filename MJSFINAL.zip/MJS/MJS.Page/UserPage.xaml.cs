﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for UserPage.xaml
    /// </summary>
    public partial class UserPage : Window
    {
        public UserPage()
        {
            InitializeComponent();
        }

        SongsBL bobj = new SongsBL();

        private void btnactress_Click(object sender, RoutedEventArgs e)
        {
            grdsong.ItemsSource = bobj.SearchSongByActress(txtcontent.Text.ToString());
            //txtcontent.Text = "";
            //txtcontent.Focus();
        }

        private void btnactor_Click(object sender, RoutedEventArgs e)
        {
            grdsong.ItemsSource = bobj.SearchSongByActor(txtcontent.Text);
        }

        private void btnsinger_Click(object sender, RoutedEventArgs e)
        {
            grdsong.ItemsSource = bobj.SearchSongBySinger(txtcontent.Text);
        }

        private void btnlang_Click(object sender, RoutedEventArgs e)
        {
            grdsong.ItemsSource = bobj.SearchSongByLanguage(txtcontent.Text);
        }

        private void btnyear_Click(object sender, RoutedEventArgs e)
        {
            if (txtcontent.Text !="")
            {
                int y = Convert.ToInt32(txtcontent.Text);
                grdsong.ItemsSource = bobj.SearchSongByYear(y);
            }
            else
            {
                MessageBox.Show("Year Cant be Empty");
            }
        }

        private void btnmovie_Click(object sender, RoutedEventArgs e)
        {
            grdsong.ItemsSource = bobj.SearchSongByMovie(txtcontent.Text);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            UpdateCustomer ucobj = new UpdateCustomer();
            ucobj.Show();
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            HomePage hpo = new HomePage();
            hpo.Show();
            this.Close();
        }
    }
}
