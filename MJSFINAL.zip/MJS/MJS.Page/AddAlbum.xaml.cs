﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;


namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for AddAlbum.xaml
    /// </summary>
    public partial class AddAlbum : Window
    {
        public AddAlbum()
        {
            InitializeComponent();
        }

        private void btnregister_Click(object sender, RoutedEventArgs e)//OK
        {
            try
            {
                AlbumBL obj = new AlbumBL();
                Album ao = new Album();

                ao.AlbumID = Convert.ToInt32(txtid.Text);
                ao.AlbumName = txtname.Text;
                ao.Category = txtcategory.Text;
                ao.Company = txtcompany.Text;
                ao.Language = txtlanguage.Text;
                ao.No_Of_Songs = Convert.ToInt32(txtnoofsongs.Text);
                ao.Price = Convert.ToDecimal(txtprice.Text);
                ao.ReleaseDate = Convert.ToDateTime(txtreleasedate.Text);
                bool flag = obj.AddAlbum(ao);

                if (flag)
                {
                    MessageBox.Show("Album Added");
                }
                else
                {
                    MessageBox.Show("Unable to Add Album");
                }

            }
            catch (AlbumExceptions aex)
            {
                MessageBox.Show(aex.Message.ToString());
            }
            catch (SqlException v)
            {
                MessageBox.Show(v.Message.ToString());
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message.ToString());
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
