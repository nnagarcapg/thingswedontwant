﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using System.Configuration;
using WMPLib;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;
using System.IO;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for HomePage.xaml
    /// </summary>
    public partial class HomePage : Window
    {
        WMPLib.WindowsMediaPlayer player = new WindowsMediaPlayer();
        int c = 0;
        int i = 0;
        public HomePage()
        {
            InitializeComponent();
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            Login loo = new Login();
            loo.Show();
            this.Close();
        }

        private void Hyperlink_Click_1(object sender, RoutedEventArgs e)
        {
            Registration rego = new Registration();
            rego.Show();
            this.Close();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            SongsBL sbo = new SongsBL();
            dgrsongs.ItemsSource = sbo.SearchSongByYear(2017);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Songs so = (Songs)dgrsongs.SelectedItem;
            if (c == 0)
            {
                SongsBL obj = new SongsBL();
                int k = obj.DownloadSong(so.SongsID);
                player.URL = @"P:\songs\song"+k+".mp3";
                MessageBox.Show("Playing");
                player.controls.play();
                c = 1;
            }
            else
            {
                if (c == 1)
                {
                    player.controls.pause();
                    c = 2;
                }
                else if(c == 2)
                {
                    player.controls.play();
                    c = 1;
                }
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Songs so = (Songs)dgrsongs.SelectedItem;
            if (i != so.SongsID)
            {
                SongsBL obj = new SongsBL();
                int k = obj.DownloadSong(so.SongsID);
                MessageBox.Show("Song Dowloaded by Name: Song"+k);
            }
            else
            {
                MessageBox.Show("You Already have this song");
            }
        }
    }
}
