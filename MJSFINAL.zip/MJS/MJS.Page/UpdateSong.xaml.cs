﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using MJS.Exceptions;
using MJS.Entity;
using MJS.BL;
using System.Data.SqlClient;

namespace MJS.Page
{
    /// <summary>
    /// Interaction logic for UpdateSong.xaml
    /// </summary>
    public partial class UpdateSong : Window
    {
        public UpdateSong()
        {
            InitializeComponent();
        }

        private void btnupdatesong_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                SongsBL obj = new SongsBL();
                Songs so = new Songs();

                so.Actor = txtactor.Text;
                so.Actress = txtacctress.Text;
                so.AlbumID = Convert.ToInt32(txtalbumid.Text);
                so.ComposedBy = txtcomposed.Text;
                so.Language = txtlanguage.Text;
                so.Lyrics = txtlyrics.Text;
                so.Movie = txtmovie.Text;
                so.Singer = txtsinger.Text;
                so.SongName = txtsongname.Text;
                so.SongsID = Convert.ToInt32(txtsongid.Text);
                so.Year = Convert.ToInt32(txtyear.Text);

                bool flag = obj.UpdateSong(so);
                if (flag)
                {
                    MessageBox.Show("Song Updated");
                }
                else
                {
                    MessageBox.Show("Unable to update song");
                }
            }
            catch (SongsExceptions ses)
            {
                MessageBox.Show(ses.Message.ToString());
            }
            catch (SqlException v)
            {
                MessageBox.Show(v.Message.ToString());
            }
            catch (Exception w)
            {
                MessageBox.Show(w.Message.ToString());
            }
        }

        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
