--use NNPractice
--use Mumbai13Training

--CREATE SCHEMA MJS --ok

--Creating Customer Table
--1								First Table to Be Created
CREATE TABLE MJS.Customer 
(
	CustomerID INT PRIMARY KEY,
	CustName VARCHAR(100),
	Addess VARCHAR(250),
	DOB DATE, --YYYY-MM-DD
	City VARCHAR(60),
	Pass VARCHAR(15) NOT NULL,
	MobileNo INT
)--Work OK. No Need To enter PK. Mobile Takes 10 Digit Number.

INSERT INTO MJS.Customer VALUES('Demo Name 1', 'Demo Addess 1', '1995-12-21', 'Demo City 1', 'Demo pass 1', 1234567890 )
--Select * FROM MJS.Customer WHERE CustomerID=
DELETE FROM MJS.Customer WHERE CustomerID = 1000
DELETE FROM MJS.Customer
DROP TABLE MJS.Customer
--#############################################################################################################################################
--Creating Employee Table
--2							Second Table to Be Created
CREATE TABLE MJS.Employee
(
	EmployeeID INT IDENTITY(1000,1) PRIMARY KEY,
	EmpName VARCHAR(100),
	Addess VARCHAR(250),
	DOB DATE, --YYYY-MM-DD
	City VARCHAR(60),
	Pass VARCHAR(15) NOT NULL,
	MobileNo INT
)--Works OK. No Need To enter PK. Mobile Takes 10 Digit Number.

INSERT INTO MJS.Employee VALUES('Demo EName 1', 'Demo EAddess 1', '1995-12-21', 'Demo ECity 1', 'Demo Epass 1', 1234567890)
SELECT * FROM MJS.Employee
DELETE FROM MJS.Employee WHERE EmployeeID = 1001

--SET IDENTITY_INSERT Mumbai13Training.MJS.Employee OFF
--SET IDENTITY_INSERT Mumbai13Training.MJS.Employee ON
DROP TABLE MJS.Employee
--Creating Procedure
GO
CREATE PROCEDURE usp_MJSemployeeInsert
(
	@id INT,
	@n VARCHAR(100),
	@a VARCHAR(250),
	@dob DATE,
	@c VARCHAR(60),
	@p VARCHAR(15),
	@mn INT
)
AS
BEGIN
	IF(@id = NULL)
		BEGIN
			INSERT INTO MJS.Employee VALUES(@n, @a, @dob, @c, @p, @mn)
		END
	ELSE
		BEGIN
			SET IDENTITY_INSERT Mumbai13Training.MJS.Employee ON
			INSERT INTO MJS.Employee VALUES(@id, @n, @a, @dob, @c, @p, @mn)
			SET IDENTITY_INSERT Mumbai13Training.MJS.Employee OFf
		END
END
GO

--#############################################################################################################################################
--Creating Album Table
--3 						Third Table to Be Created
CREATE TABLE MJS.Album
(
	AlbumID INT IDENTITY(1000,1) PRIMARY KEY, 
	AlbumName VARCHAR(100),
	Category VARCHAR(15),
	NoOFSongs INT,
	ReleaseDate DATE,--YYYY-MM-DD
	Company VARCHAR(50),
	Price MONEY,
	Lang VARCHAR(30)
)--Works OK. No Need To enter PK.

INSERT INTO MJS.Album VALUES('Demo Album 1', 'Demo Cat 1', 4, '2017-10-12', 'Demo Company 1', 8000, 'Demo Language 1')
SELECT * FROM MJS.Album 
SELECT * FROM MJS.Songs
DELETE FROM MJS.Album WHERE AlbumID = 1000

DECLARE @y int
SET @y=2017
select * from MJS.Album where DATEPART(year,ReleaseDate) = @y
DROP TABLE MJS.Album
exec dbo.mk_RemoveCustomer

--#############################################################################################################################################
--Creating SONGS Table
--4 						Fourth Table to Be Created
CREATE TABLE MJS.Songs
(
	SongID INT IDENTITY(1000,1) PRIMARY KEY,
	SongName VARCHAR(50),
	Singer VARCHAR(50),
	Movie VARCHAR(50),
	ComposedBy VARCHAR(50),
	Actor VARCHAR(50),
	Actess VARCHAR(50),
	Lyrics VARCHAR(100),
	RYear INT,
	AlbumID INT FOREIGN KEY REFERENCES MJS.Album(AlbumID),
	Lang VARCHAR(30)
)--Works OK. No need PK. RYear columns takes special insert query to only store years. FK in working but is accepting null values.

INSERT INTO MJS.Songs VALUES('Demo SName 1', 'Demo SName 1', 'Demo MName 1', 'Demo CName 1', 'Demo AName 1', 'Demo AName 1', 'Demo Lyrics 1', YEAR('1995-12-12'), 1000, 'Demo Lang 1')
--SELECT * FROM MJS.Songs WHERE SongID=
DELETE FROM MJS.Songs WHERE SongID = 1002
DROP TABLE MJS.Songs
-UPDATE MJS.Songs SET SongName=@n, Singer=@s, Movie=@m, ComposedBy=@c, Actor=@a, Actress=@ac, Lyrics=@l, RYear=@y, AlbumID=@ai, Lang=@lang WHERE SongID=@i 

--#############################################################################################################################################
--Creating MusicOrder Table
--5 						Fifth Table to Be Created
CREATE TABLE MJS.MusicOrder
(
	OrderID INT IDENTITY(1000,1) PRIMARY KEY,
	OrderDate DATE,
	DeliveryDate DATE,
	OrdPaymentID INT,
	EmployeeID INT FOREIGN KEY REFERENCES MJS.Employee(EmployeeID),
	CustomerID INT FOREIGN KEY REFERENCES MJS.Customer(CustomerID)
)--Wokrs Ok. No need to enter PK. Date Columns cancel out time part automatically. FK References Works. Have to do something about OrdPymentID.

INSERT INTO MJS.MusicOrder VALUES(GETDATE(), GETDATE(), 1000, 1002,1001)
SELECT * FROM MJS.MusicOrder
DELETE FROM MJS.MusicOrder WHERE OrderID=1002
DROP TABLE MJS.MusicOrder
--#############################################################################################################################################
--Creating Payment Table
--6 						Sixth Table to Be Created
CREATE TABLE MJS.Payment
(
	PaymentID INT IDENTITY(1000,1) PRIMARY KEY,
	PayAccName VARCHAR(100),
	PayOrderID INT FOREIGN KEY REFERENCES MJS.MusicOrder(OrderID),
	PaymentDate DATE,
	Amount Money,
	PaymentMethod VARCHAR(20)
)--Works OK.

INSERT INTO MJS.Payment VALUES('Demo AccName 1', 1002, '2018-12-12', 8000, 'Net Banking')
SELECT * FROM MJS.Payment
DELETE FROM MJS.Payment WHERE PaymentID=1000
DROP TABLE MJS.Payment

--#############################################################################################################################################
--Creating MusicOrderDetails Table
--7 						Seventh Table to Be Created
CREATE TABLE MJS.MusicOrderDetails
(
	MusicOrderID INT FOREIGN KEY REFERENCES MJS.MusicOrder(OrderID) NOT NULL,
	AlbumID INT FOREIGN KEY REFERENCES MJS.Album(AlbumID),
	UnitPrice MONEY,
	Qty INT,
	Discount INT,
	PaymentID INT FOREIGN KEY REFERENCES MJS.Payment(PaymentID),
	TotAmount AS ((UnitPrice*Qty)*Discount) --PERSISTED
)

INSERT INTO MJS.MusicOrderDetails VALUES(1002, 1000, 8,2,1, 1000)
SELECT * FROM MJS.MusicOrderDetails
DELETE FROM MJS.MusicOrderDetails WHERE MusicOrderID=1002
DROP TABLE MJS.MusicOrderDetails

--#############################################################################################################################################
--Creating Storing Procedure
--1
GO
CREATE PROCEDURE usp_MJSMusicOrder
(
	@od DATE,
	@dd DATE,
	@ei INT,
	@ci INT,
	@moi INT,
		
)
AS
BEGIN

END
GO

exec sp_help Customer