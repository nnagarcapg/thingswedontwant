﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using PFP.Exceptions;
using PFP.Entity;
using PFP.BL;

namespace PFP.UI.ASP
{
    public partial class SearchProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsearch_Click(object sender, EventArgs e)
        {
            try
            {
                ProductBL obj = new ProductBL();
                int id = Convert.ToInt32(txtid.Text);
                Product p = obj.SearchProduct(id);
                //p = obj.SearchProduct(id);

                if (p != null)
                {
                    txtname.Text = p.ProductName;
                    txtprice.Text = p.Price.ToString();
                }
                else
                {
                    lblmsg.Text = "No Such Record found";
                }
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message.ToString();
            }
            catch (Exception v)
            {
                lblmsg.Text = v.Message.ToString();
            }
        }
    }
}