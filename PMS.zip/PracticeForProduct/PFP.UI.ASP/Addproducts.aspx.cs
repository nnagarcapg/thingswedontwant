﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using PFP.Exceptions;
using PFP.Entity;
using PFP.BL;

namespace PFP.UI.ASP
{
    public partial class Addproducts : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            ProductBL obj = new ProductBL();
            txtid.Text = Convert.ToString(obj.MaxProdId());
        }

        protected void btnaddproduct_Click(object sender, EventArgs e)
        {
            try
            {
                ProductBL obj = new ProductBL();
                Product o = new Product();
                o.PID = Convert.ToInt32(txtid.Text);
                o.ProductName = txtname.Text;
                o.Price = Convert.ToDecimal(txtprice.Text);
                bool flag = obj.AddProduct(o);
                if (flag)
                {
                    lblmsg.Text = "New Product Added With Id:- " + o.PID;
                }
                else
                {
                    lblmsg.Text = "Unable to add Product";
                }
            }
            catch(SqlException s)
            {
                lblmsg.Text = s.Message.ToString();
            }
            catch (Exception v)
            {
                lblmsg.Text = v.Message.ToString();
            }
        }

        protected void txtrefresh_Click(object sender, EventArgs e)
        {
            Page_Load(sender, e);
            lblmsg.Text = "";
            txtname.Text = "";
            txtprice.Text = "";
        }
    }
}