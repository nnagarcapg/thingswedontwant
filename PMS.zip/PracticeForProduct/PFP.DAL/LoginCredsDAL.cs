﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using PFP.Entity;

namespace PFP.DAL
{
    public class LoginCredsDAL
    {
        public bool LoginCredentials(LoginCreds rec)
        {
            //Write ado.net querry
            SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["CS"].ConnectionString);
            try
            {
                SqlCommand cmd = new SqlCommand("SELECT * FROM HMS_NN.LoginCreds where USERNAME=@u AND PASS=@p", con);

                cmd.Parameters.AddWithValue("@u", rec.UserName);
                cmd.Parameters.AddWithValue("@p", rec.Pass);

                con.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    con.Close();
                    return true;
                }
                else
                {
                    con.Close();
                    return false;
                }
            }
            catch (SqlException s)
            {
                con.Close();
                throw s;
            }
            catch (Exception v)
            {
                con.Close();
                throw v;
            }
        }
    }
}
