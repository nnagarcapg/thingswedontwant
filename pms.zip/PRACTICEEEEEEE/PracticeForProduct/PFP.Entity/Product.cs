﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PFP.Entity
{
    public class Product
    {
        #region Fields
        int pID;
        string productName;
        decimal price;
        #endregion

        #region Properties
        public decimal Price
        {
            get { return price; }
            set { price = value; }
        }

        public string ProductName
        {
            get { return productName; }
            set { productName = value; }
        }

        public int PID
        {
            get { return pID; }
            set { pID = value; }
        }
        #endregion
    }
}
