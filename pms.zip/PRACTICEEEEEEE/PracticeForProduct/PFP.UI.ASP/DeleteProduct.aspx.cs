﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data.SqlClient;
using PFP.Exceptions;
using PFP.Entity;
using PFP.BL;

namespace PFP.UI.ASP
{
    public partial class DeleteProduct : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            try
            {
                ProductBL obj = new ProductBL();
                int id = Convert.ToInt32(txtid.Text);
                bool flag = obj.DeleteProduct(id);
                if (flag)
                {
                    lblmsg.Text = "Product Is Successfully Added";
                }
                else
                {
                    lblmsg.Text = "Unable to Delete Product";
                }
            }
            catch (SqlException s)
            {
                lblmsg.Text = s.Message.ToString();
            }
            catch (Exception v)
            {
                lblmsg.Text = v.Message.ToString();
            }
        }
    }
}